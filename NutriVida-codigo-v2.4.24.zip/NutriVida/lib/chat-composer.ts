export function resizeChatComposer(field:HTMLTextAreaElement,root:HTMLElement){
 field.style.height='44px';
 const height=Math.max(44,Math.min(132,field.scrollHeight));
 field.style.height=`${height}px`;
 field.style.overflowY=field.scrollHeight>132?'auto':'hidden';
 root.style.setProperty('--chat-composer-extra',`${height-44}px`);
}
