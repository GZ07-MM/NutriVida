// Format the display only. Profile validation and ISO storage stay unchanged.
export function formatBirthDate(value:string){
 const digits=value.replace(/\D/g,'').slice(0,8);
 return digits.slice(0,2)+(digits.length>=2?'/':'')+digits.slice(2,4)+(digits.length>=4?'/':'')+digits.slice(4);
}
export function editBirthDate(previous:string,value:string,selection:number,inputType=''){
 if(/^\d{4}-\d{2}-\d{2}$/.test(value))return {text:value.split('-').reverse().join('/'),caret:10};
 let digits=value.replace(/\D/g,'').slice(0,8),count=value.slice(0,selection).replace(/\D/g,'').length;
 // Backspace over an inserted slash also removes the preceding digit, so the
 // separator cannot trap the cursor. Delete works in the opposite direction.
 if(value.length<previous.length&&digits===previous.replace(/\D/g,'')){
  const forward=inputType==='deleteContentForward',index=forward?count:count-1;
  if(index>=0&&index<digits.length){digits=digits.slice(0,index)+digits.slice(index+1);if(!forward)count--;}
 }
 const text=formatBirthDate(digits),n=Math.max(0,Math.min(count,digits.length));
 return {text,caret:Math.min(text.length,n+(n>=2?1:0)+(n>=4?1:0))};
}
