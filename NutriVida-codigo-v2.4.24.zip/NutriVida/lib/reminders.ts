const validTime=(x:string)=>/^([01]\d|2[0-3]):[0-5]\d$/.test(x);
export function awakeAt(now:Date,sleep:string,wake:string){if(!validTime(sleep)||!validTime(wake)||sleep===wake)return true;const minutes=(s:string)=>Number(s.slice(0,2))*60+Number(s.slice(3));const n=now.getHours()*60+now.getMinutes(),start=minutes(wake),end=minutes(sleep);return start<end?n>=start&&n<end:n>=start||n<end}
const escape=(s:string)=>s.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/,/g,'\\,').replace(/;/g,'\\;');
function fold(s:string){let line='',result='';for(const c of s){if(new TextEncoder().encode(line+c).length>73){result+=line+'\r\n ';line=''}line+=c}return result+line}
export function reminderCalendar(day:string,settings:{wake:string;sleep:string;waterInterval:number},kind:'water'|'sleep',lang='pt'){
 const min=(s:string)=>Number(s.slice(0,2))*60+Number(s.slice(3));
 if(!validTime(settings.wake)||!validTime(settings.sleep)||settings.wake===settings.sleep)throw new Error('Escolha horários diferentes para dormir e acordar.');
 const times:number[]=[];const start=min(settings.wake),end=min(settings.sleep)+(min(settings.sleep)<start?1440:0);
 if(kind==='water'){if(![30,60,90,120].includes(settings.waterInterval))throw new Error('Intervalo inválido.');for(let t=start+settings.waterInterval;t<end;t+=settings.waterInterval)times.push(t)}else times.push(start);
 const lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//NutriVida//Reminders//PT','CALSCALE:GREGORIAN','METHOD:PUBLISH'];
 const stamp=new Date().toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,'');
 for(const [i,time] of times.entries()){const d=new Date(day+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+Math.floor(time/1440));const date=d.toISOString().slice(0,10).replace(/-/g,'');const clock=String(Math.floor(time%1440/60)).padStart(2,'0')+String(time%60).padStart(2,'0')+'00';const title=kind==='water'?(lang==='en'?'NutriVida · Water break':lang==='es'?'NutriVida · Beber agua':'NutriVida · Beber água'):(lang==='en'?'NutriVida · Wake up':lang==='es'?'NutriVida · Despertar':'NutriVida · Acordar');lines.push('BEGIN:VEVENT',`UID:nutrivida-${kind}-${i}@reminders`,`DTSTAMP:${stamp}`,`DTSTART:${date}T${clock}`,'DURATION:PT1M','RRULE:FREQ=DAILY',`SUMMARY:${escape(title)}`,'BEGIN:VALARM','ACTION:DISPLAY','TRIGGER:PT0M',`DESCRIPTION:${escape(title)}`,'END:VALARM','END:VEVENT')}
 lines.push('END:VCALENDAR');return lines.map(fold).join('\r\n')+'\r\n';
}
