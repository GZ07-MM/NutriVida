export function sleepMinutes(sleep:string,wake:string){
  if(!/^\d{2}:\d{2}$/.test(sleep)||!/^\d{2}:\d{2}$/.test(wake))return 0;
  const [sh,sm]=sleep.split(":").map(Number),[wh,wm]=wake.split(":").map(Number);
  if(sh>23||wh>23||sm>59||wm>59)return 0;
  return (wh*60+wm-sh*60-sm+1440)%1440;
}
export function alarmIsDue(now:Date,wake:string,lastKey:string|null){
  if(!/^\d{2}:\d{2}$/.test(wake))return false;
  const [h,m]=wake.split(":").map(Number);if(h>23||m>59)return false;
  const key=`${now.toLocaleDateString("sv-SE")}-${wake}`,current=now.getHours()*60+now.getMinutes(),target=h*60+m;
  return lastKey!==key&&current>=target&&current<target+2;
}
