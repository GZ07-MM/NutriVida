// Track both overlay keyboards and WebViews that resize the layout viewport.
export function followChatKeyboard(win:Window,input:HTMLInputElement|HTMLTextAreaElement,reveal:()=>void,measureLayout=()=>{}){
 const viewport=win.visualViewport,root=win.document.documentElement;
 let baseline=viewport?.height||win.innerHeight,width=viewport?.width||win.innerWidth,opened=false,tracking=false,frame=0,lastHeight=0,lastKeyboardHeight=0,suspended=false,disposed=false,recoveryFrames=0,restorePending=false;
 const clearGeometry=()=>{
  for(const key of ['--chat-keyboard-inset','--chat-keyboard-height','--chat-viewport-height','--chat-viewport-top'])root.style.removeProperty(key);
  root.classList.remove('chatKeyboard');
 };
 const update=()=>{
  frame=0;
  if(disposed||suspended||win.document.visibilityState==='hidden')return;
  const height=viewport?.height||win.innerHeight,currentWidth=viewport?.width||win.innerWidth,scale=viewport?.scale||1;
  // Some WebViews report zero sizes while their surface is being restored.
  if(!Number.isFinite(height)||height<=0||!Number.isFinite(currentWidth)||currentWidth<=0){if(recoveryFrames-->0)schedule();return}
  const focused=win.document.activeElement===input;
  if(focused)tracking=true;
  if(Math.abs(currentWidth-width)>80&&scale===1){baseline=Math.max(height,win.innerHeight);width=currentWidth}
  if(!focused&&!opened&&!tracking)baseline=height;
  baseline=Math.max(baseline,height);
  // A stale pan offset must never push the restored full-height chat off-screen.
  const top=scale===1&&focused?Math.max(0,Math.min(viewport?.offsetTop||0,win.innerHeight-height)):0;
  const inset=scale===1?Math.max(0,win.innerHeight-height-top):0;
  // Keep the remaining navigation space continuous throughout the animation.
  // A boolean keyboard threshold must never move the composer by a whole nav height.
  const keyboardHeight=scale===1&&(focused||opened||tracking)?Math.max(0,baseline-height,inset):0;
  const next=keyboardHeight>(opened?2:120);
  if(!focused&&keyboardHeight<=2)tracking=false;
  root.style.setProperty('--chat-viewport-height',`${scale===1?height:win.innerHeight}px`);
  root.style.setProperty('--chat-viewport-top',`${top}px`);
  root.classList.add('chatScreen');
  root.style.setProperty('--chat-keyboard-inset',`${next?inset:0}px`);
  root.style.setProperty('--chat-keyboard-height',`${keyboardHeight}px`);
  root.classList.toggle('chatKeyboard',next);
  measureLayout();
  if(restorePending||(keyboardHeight>0||opened)&&(height!==lastHeight||keyboardHeight!==lastKeyboardHeight||next!==opened))reveal();
  restorePending=false;
  lastHeight=height;lastKeyboardHeight=keyboardHeight;
  opened=next;
  if(recoveryFrames-->0)schedule();
 };
 const schedule=()=>{if(!disposed&&!suspended&&!frame)frame=win.requestAnimationFrame(update)};
 const reset=()=>{baseline=Math.max(win.innerHeight,viewport?.height||0);width=viewport?.width||win.innerWidth;schedule()};
 const pause=()=>{
  if(disposed||suspended||win.NutriVidaAndroid?.dictationPermissionPending?.())return;suspended=true;if(frame)win.cancelAnimationFrame(frame);frame=0;
  opened=false;tracking=false;recoveryFrames=0;clearGeometry();
  // Keep the draft, but do not restore an obsolete focused keyboard session.
  if(win.document.activeElement===input)input.blur();
 };
 const resume=()=>{
  if(disposed||win.document.visibilityState==='hidden')return;
  if(suspended){suspended=false;baseline=viewport?.height||win.innerHeight;width=viewport?.width||win.innerWidth;lastHeight=0;lastKeyboardHeight=0;restorePending=true}
  // Android applies the new WebView bounds after onResume/window focus.
  recoveryFrames=3;schedule();
 };
 const visibility=()=>{if(win.document.visibilityState==='hidden')pause();else resume()};
 viewport?.addEventListener('resize',schedule);viewport?.addEventListener('scroll',schedule);
 win.addEventListener('resize',schedule);win.addEventListener('pageshow',resume);win.addEventListener('orientationchange',reset);
 win.addEventListener('focus',resume);win.addEventListener('pagehide',pause);win.addEventListener('nutrivida-pause',pause);win.addEventListener('nutrivida-resume',resume);win.document.addEventListener('visibilitychange',visibility);
 input.addEventListener('focus',schedule);input.addEventListener('blur',schedule);
 update();
 return()=>{
  disposed=true;if(frame)win.cancelAnimationFrame(frame);
  viewport?.removeEventListener('resize',schedule);viewport?.removeEventListener('scroll',schedule);
  win.removeEventListener('resize',schedule);win.removeEventListener('pageshow',resume);win.removeEventListener('orientationchange',reset);
  win.removeEventListener('focus',resume);win.removeEventListener('pagehide',pause);win.removeEventListener('nutrivida-pause',pause);win.removeEventListener('nutrivida-resume',resume);win.document.removeEventListener('visibilitychange',visibility);
  input.removeEventListener('focus',schedule);input.removeEventListener('blur',schedule);
  clearGeometry();root.classList.remove('chatScreen');
 };
}
