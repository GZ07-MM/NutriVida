// Reading older messages pauses automatic following; reaching the bottom resumes it.
export function followChatScroll(win:Window,end:HTMLElement,composer:HTMLElement,container?:HTMLElement){
 let pinned=true,disposed=false;
 const target=container||win;
 const update=()=>{pinned=container?container.scrollHeight-container.clientHeight-container.scrollTop<=80:end.getBoundingClientRect().bottom<=composer.getBoundingClientRect().top+80};
 target.addEventListener('scroll',update,{passive:true});
 return {
  reveal(behavior:ScrollBehavior='auto',force=false){if(!disposed&&(pinned||force)){if(force)pinned=true;if(container)container.scrollTo({top:Math.max(0,container.scrollHeight-container.clientHeight),behavior});else end.scrollIntoView({block:'nearest',behavior})}},
  dispose(){disposed=true;target.removeEventListener('scroll',update)}
 };
}
