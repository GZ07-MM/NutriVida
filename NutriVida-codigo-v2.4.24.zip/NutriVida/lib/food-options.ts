export const allergens=[['milk','Leite'],['eggs','Ovos'],['nuts','Castanhas e nozes'],['peanuts','Amendoim'],['soy','Soja'],['gluten','Trigo e glúten'],['fish','Peixes'],['shellfish','Crustáceos'],['sesame','Gergelim']] as const;
export type FoodPreferences={avoid:string[];excluded:string[];diet:'any'|'vegetarian'|'vegan';budget?:'any'|'low';maxMinutes?:number;pantry?:string[];pantryOnly?:boolean};
export const defaultPreferences:FoodPreferences={avoid:[],excluded:[],diet:'any'};
export const mealTitles=['Café da manhã','Almoço','Lanche','Jantar'];
export type FoodOption={id:string;meal:number;name:string;ingredients:string[];allergens:string[];animal:'none'|'dairy-eggs'|'meat';minutes:number};
export const foodOptions:FoodOption[]=[
{id:'tapioca-banana',meal:0,name:'Tapioca com banana',ingredients:['goma de tapioca','banana','canela'],allergens:[],animal:'none',minutes:10},
{id:'cuscuz-ovo',meal:0,name:'Cuscuz com ovo',ingredients:['flocos de milho','água','ovo','azeite','sal'],allergens:['eggs'],animal:'dairy-eggs',minutes:15},
{id:'aveia-leite',meal:0,name:'Mingau de aveia',ingredients:['aveia','leite','banana','canela'],allergens:['gluten','milk'],animal:'dairy-eggs',minutes:10},
{id:'batata-mamao',meal:0,name:'Batata-doce e mamão',ingredients:['batata-doce','água','mamão'],allergens:[],animal:'none',minutes:20},
{id:'arroz-feijao',meal:1,name:'Arroz, feijão e cenoura',ingredients:['arroz','feijão','cenoura','água','azeite','sal'],allergens:[],animal:'none',minutes:40},
{id:'arroz-frango',meal:1,name:'Arroz com frango e abobrinha',ingredients:['arroz','frango','abobrinha','água','azeite','sal'],allergens:[],animal:'meat',minutes:30},
{id:'lentilha-batata',meal:1,name:'Lentilha com batata e abóbora',ingredients:['lentilha','batata','abóbora','água','azeite','sal'],allergens:[],animal:'none',minutes:30},
{id:'peixe-arroz',meal:1,name:'Peixe com arroz e brócolis',ingredients:['peixe','arroz','brócolis','água','azeite','sal'],allergens:['fish'],animal:'meat',minutes:30},
{id:'iogurte-morango',meal:2,name:'Iogurte com morangos',ingredients:['iogurte natural de leite','morango'],allergens:['milk'],animal:'dairy-eggs',minutes:5},
{id:'maca-banana',meal:2,name:'Maçã e banana picadas',ingredients:['maçã','banana'],allergens:[],animal:'none',minutes:5},
{id:'milho',meal:2,name:'Milho cozido',ingredients:['milho','água','sal'],allergens:[],animal:'none',minutes:20},
{id:'amendoim-pera',meal:2,name:'Pera com amendoim',ingredients:['pera','amendoim sem outros ingredientes'],allergens:['peanuts'],animal:'none',minutes:5},
{id:'sopa-legumes',meal:3,name:'Sopa de legumes com feijão',ingredients:['batata','cenoura','abóbora','feijão','água','azeite','sal'],allergens:[],animal:'none',minutes:30},
{id:'omelete',meal:3,name:'Omelete com arroz e cenoura',ingredients:['ovo','arroz','cenoura','água','azeite','sal'],allergens:['eggs'],animal:'dairy-eggs',minutes:20},
{id:'grao-bico',meal:3,name:'Grão-de-bico com arroz',ingredients:['grão-de-bico','arroz','abobrinha','água','azeite','sal'],allergens:[],animal:'none',minutes:30},
{id:'frango-batata',meal:3,name:'Frango com batata e cenoura',ingredients:['frango','batata','cenoura','água','azeite','sal'],allergens:[],animal:'meat',minutes:35}
];
export const normalize=(value:string)=>value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
const aliases:Record<string,string[]>={milk:['milk','dairy','cheese','yogurt','butter','leche','queso','leite','lactose','queijo','iogurte','manteiga','caseina','soro de leite'],eggs:['egg','eggs','huevo','huevos','ovo','ovos','clara','gema'],nuts:['nuts','almond','almonds','walnut','walnuts','nueces','almendras','castanha','castanhas','nozes','noz','amendoa','amendoas','avela','avelas','pistache','macadamia','peca','pinoli'],peanuts:['amendoim','peanut','peanuts','cacahuete','cacahuetes'],soy:['soja','tofu','soy'],gluten:['wheat','oats','barley','rye','trigo','gluten','aveia','cevada','centeio'],fish:['fish','pescado','salmon','tuna','peixe','peixes','atum','sardinha','salmao'],shellfish:['shellfish','shrimp','prawn','gamba','camaron','camarao','crustaceos','caranguejo','lagosta'],sesame:['gergelim','tahine','sesame','sesamo']};
const synonyms:Record<string,string>={apple:"maca",manzana:"maca",rice:"arroz",beans:"feijao",frijoles:"feijao",carrot:"cenoura",zanahoria:"cenoura",chicken:"frango",pollo:"frango",potato:"batata",patata:"batata",papaya:"mamao",corn:"milho",maiz:"milho",pear:"pera",strawberry:"morango",fresa:"morango",pumpkin:"abobora",calabaza:"abobora",lentils:"lentilha",lentejas:"lentilha",chickpeas:"grao-de-bico",garbanzos:"grao-de-bico",zucchini:"abobrinha",calabacin:"abobrinha",cinnamon:"canela",canela:"canela",milk:"leite",leche:"leite",egg:"ovo",huevo:"ovo",oats:"aveia",avena:"aveia"};
const canonical=(s:string)=>synonyms[normalize(s)]||normalize(s);
export function filterFoods(preferences:FoodPreferences,meal:number){
 const blocked=new Set(preferences.avoid);const excluded=preferences.excluded.map(normalize).map(x=>synonyms[x]||x).filter(Boolean);
 for(const term of excluded)for(const [tag,words] of Object.entries(aliases))if(words.some(word=>(` ${term} `).includes(` ${word} `)))blocked.add(tag);
 const available=(preferences.pantry||[]).map(canonical);const basic=['água','sal','azeite'];const has=(ingredient:string)=>basic.includes(ingredient)||available.some(x=>normalize(ingredient).includes(x)||x.includes(normalize(ingredient)));return foodOptions.filter(option=>option.meal===meal&&!(preferences.diet==='vegan'&&option.animal!=='none')&&!(preferences.diet==='vegetarian'&&option.animal==='meat')&&(!preferences.maxMinutes||option.minutes<=preferences.maxMinutes)&&(preferences.budget!=='low'||!['peixe-arroz','iogurte-morango','amendoim-pera'].includes(option.id))&&(!preferences.pantryOnly||option.ingredients.every(has))&&!option.allergens.some(tag=>blocked.has(tag))&&!option.ingredients.some(ingredient=>excluded.some(term=>normalize(ingredient).includes(term)||term.startsWith(normalize(ingredient)+' ')||term===normalize(ingredient)+'s'))).sort((a,b)=>available.length?b.ingredients.filter(has).length/b.ingredients.length-a.ingredients.filter(has).length/a.ingredients.length||a.minutes-b.minutes:a.minutes-b.minutes);
}

export function missingIngredients(option:FoodOption,pantry:string[]){const available=pantry.map(canonical);return option.ingredients.filter(i=>!['água','sal','azeite'].includes(i)&&!available.some(x=>normalize(i).includes(x)||x.includes(normalize(i))))}
export const preparation:Record<string,string>={
 'tapioca-banana':'Aqueça a goma em frigideira até formar a tapioca. Recheie com banana e canela.',
 'cuscuz-ovo':'Hidrate os flocos e cozinhe no vapor. Cozinhe o ovo completamente e sirva com o cuscuz.',
 'aveia-leite':'Aqueça leite e aveia, mexendo até engrossar. Acrescente banana e canela.',
 'batata-mamao':'Cozinhe a batata-doce em água até ficar macia. Sirva com mamão lavado e cortado.',
 'arroz-feijao':'Cozinhe arroz e feijão. Cozinhe ou rale a cenoura e sirva juntos.',
 'arroz-frango':'Cozinhe o arroz. Cozinhe o frango completamente e refogue a abobrinha. Sirva juntos.',
 'lentilha-batata':'Cozinhe lentilha, batata e abóbora em água até ficarem macias. Tempere ao seu gosto.',
 'peixe-arroz':'Cozinhe o arroz e o brócolis. Cozinhe o peixe completamente e sirva juntos.',
 'iogurte-morango':'Lave e corte os morangos. Misture ao iogurte e mantenha refrigerado até servir.',
 'maca-banana':'Lave a maçã e descasque a banana. Corte e sirva.',
 'milho':'Cozinhe o milho em água até ficar macio e escorra antes de servir.',
 'amendoim-pera':'Lave e corte a pera. Sirva com amendoim pronto para consumo.',
 'sopa-legumes':'Cozinhe os legumes em água até ficarem macios. Acrescente o feijão já cozido e aqueça.',
 'omelete':'Prepare o arroz e a cenoura. Bata o ovo e cozinhe completamente em frigideira. Sirva juntos.',
 'grao-bico':'Cozinhe o grão-de-bico e o arroz. Refogue a abobrinha e sirva juntos.',
 'frango-batata':'Cozinhe o frango completamente. Cozinhe batata e cenoura até ficarem macias e sirva juntos.'
};
