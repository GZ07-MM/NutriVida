import type {Event} from './domain';

export function monthInfo(month:string){
 const [year,index]=month.split('-').map(Number);
 return {year,month:index-1,days:new Date(Date.UTC(year,index,0)).getUTCDate(),offset:(new Date(Date.UTC(year,index-1,1)).getUTCDay()+6)%7};
}
export function shiftMonth(month:string,amount:number){
 const {year,month:index}=monthInfo(month);
 return new Date(Date.UTC(year,index+amount,1)).toISOString().slice(0,7);
}
export function calendarStart(created:string,day:string,events:Event[]){
 const first=[created,day,...events.map(e=>e.day)].filter(d=>/^\d{4}-\d{2}-\d{2}$/.test(d)).sort()[0]||day;
 return first.slice(0,4)+'-01';
}
