import type {ChatMessage} from './chat-view';
export const normalizeChat=(text:string)=>text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
type Topic='food'|'water'|'sleep'|'workout'|'routine'|'health';
export function chatTopic(q:string):Topic|undefined{
 if(/\b(dor|pain|dolor|doenca|doente|sick|desmaio)\b|diabet|gravida|pregnan|enfermed/.test(q))return 'health';
 if(/agua|water|hidrat|copos|vasos/.test(q))return 'water';
 if(/sono|dorm|sleep|despert|acord|sueno/.test(q))return 'sleep';
 if(/trein|workout|exerc|flex|agach|muscul|entren|corrida|caminh|walk/.test(q))return 'workout';
 if(/alerg|allerg|alimenta|food|comer|refeic|meal|comida|leite|arroz|feijao|banana|proteina|veget|vegan|nutrition|frango|lentilha|ovos?|carne|calor|kcal|emagrec|deficit|engord/.test(q))return 'food';
 if(/meta|goal|objetiv|rotina|routine|habit|misso|mission|joia|gem|patente|rank|perfil|profile|relator|report|nutrivida|loja|store|\bxp\b/.test(q))return 'routine';
}
const followUp=(q:string)=>q.length<=220&&(/exempl|examples?|ejempl|expli|detalh|entendi|entender|entend|continu|outr|alternativ|substitu|trocar|troca|sem |without |sin |nao gosto|no lugar|por que|porque|como faz|como assim|how|why/.test(q)||/^(e |mas |mais |but |and |y |pero |sim\b|yes\b|si\b|pode\b|quero\b|prefiro\b|so \d|\d{2,4}[ ?.!]*$)/.test(q));
// Only user turns provide constraints. A new subject (including an unrelated one)
// ends the old thread, so a follow-up never resurrects an older topic.
export function conversationContext(text:string,messages:ChatMessage[]=[]){
 let topic:Topic|undefined,turns:string[]=[];
 for(const m of [...messages.slice(-30).filter(m=>m.role==='user'),{role:'user' as const,text}]){
  const q=normalizeChat(m.text),direct=chatTopic(q);
  if(/^(oi|ola|hello|hi|hola|bom dia|boa noite|obrigad[oa]?|thanks|gracias)[ !.?]*$/.test(q))continue;
  if(/novo assunto|mudar de assunto|esquece|forget|new topic/.test(q)){topic=direct;turns=direct?[q]:[];continue}
  if(direct){if(direct!==topic)turns=[];topic=direct;turns.push(q)}
  else if(topic&&followUp(q))turns.push(q);
  else {topic=undefined;turns=[]}
 }
 return {topic,turns,q:normalizeChat(text)};
}
