import {normalizeChat} from './chat-context';
import {defaultPreferences,type FoodPreferences} from './food-options';
// kcal/100 g, prepared edible portion: TACO 4th ed., NEPA/UNICAMP (2011),
// items 3, 410, 488, 561, 577. Oil/sauces are not part of these estimates.
// https://nepa.unicamp.br/wp-content/uploads/sites/27/2023/10/taco_4_edicao_ampliada_e_revisada.pdf
const foods={
 rice:{name:['arroz branco cozido','cooked white rice','arroz blanco cocido'],kcal:128,animal:false,allergen:'',terms:['arroz','rice']},
 beans:{name:['feijão carioca cozido','cooked carioca beans','frijoles carioca cocidos'],kcal:76,animal:false,allergen:'',terms:['feijao','beans','frijoles']},
 chicken:{name:['peito de frango sem pele grelhado','grilled skinless chicken breast','pechuga de pollo sin piel a la plancha'],kcal:159,animal:true,allergen:'',terms:['frango','chicken','pollo','carne','meat']},
 eggs:{name:['ovo cozido (sem casca)','boiled egg (without shell)','huevo cocido (sin cascara)'],kcal:146,animal:true,allergen:'eggs',terms:['ovo','ovos','egg','eggs','huevo','huevos']},
 lentils:{name:['lentilha cozida','cooked lentils','lentejas cocidas'],kcal:93,animal:false,allergen:'',terms:['lentilha','lentils','lentejas']}
};
type Food=keyof typeof foods;
const templates:{id:string;parts:[Food,number][]}[]=[
 {id:'chicken',parts:[['rice',220],['beans',100],['chicken',150]]},
 {id:'eggs',parts:[['rice',250],['beans',180],['eggs',100]]},
 {id:'lentils',parts:[['rice',280],['lentils',250]]},
 {id:'beans',parts:[['rice',300],['beans',280]]}
];
export function foodExamples(turns:string[],lang:string,preferences:FoodPreferences=defaultPreferences){
 const idx=lang==='en'?1:lang==='es'?2:0,say=(pt:string,en:string,es:string)=>[pt,en,es][idx];
 const combined=turns.join(' '),latest=turns.at(-1)||'';
 let target:number|undefined;
 for(const q of turns){const n=q.match(/\b(\d{2,5})\s*(?:kcal|calorias?|calories?)\b/)||q.match(/^(?:e(?: se)?(?: fossem| forem)?|mas|mais|and|what about|y)?\s*(\d{2,5})[ ?.!]*$/);if(n)target=Number(n[1])}
 if(target!==undefined&&(target<100||target>1800))return say('Esse valor é para uma refeição ou para o dia inteiro? Posso mostrar a soma de alimentos, mas não definir uma meta diária pessoal.','Is that for one meal or the entire day? I can illustrate food totals, but cannot set a personal daily target.','¿Ese valor es para una comida o todo el día? Puedo mostrar sumas de alimentos, pero no definir una meta diaria personal.');
 target??=600;
 const excluded=preferences.excluded.map(normalizeChat);
 for(const q of turns){for(const match of q.matchAll(/(?:\bsem\b|\bwithout\b|\bsin\b|nao gosto de|nao como|sou alergic[oa] a|tenho alergia a|evitar|tire|retire)\s+([^.!?;]+)/g))excluded.push(match[1])}
 const vegan=preferences.diet==='vegan'||/vegan/.test(combined),vegetarian=preferences.diet==='vegetarian'||/vegetar|sem carne|without meat|sin carne/.test(combined);
 const allowed=(id:Food)=>{const f=foods[id];return !(vegan&&f.animal)&&!(vegetarian&&id==='chicken')&&!preferences.avoid.includes(f.allergen)&&!excluded.some(e=>f.terms.some(term=>new RegExp('\\b'+term+'\\b').test(e)))};
 const available=templates.filter(t=>t.parts.every(([id])=>allowed(id)));
 if(!available.length)return say('Não encontrei uma combinação na minha base que respeite essas exclusões. Quais alimentos você pode usar? Não vou inventar ingredientes ou valores.','No combination in my database matches those exclusions. Which foods can you use? I will not invent ingredients or values.','No encontré una combinación que respete esas exclusiones. ¿Qué alimentos puedes usar? No voy a inventar ingredientes ni valores.');
 const more=/mais|outr|more|another|otro/.test(latest),offset=more?Math.max(1,turns.filter(q=>/exempl|outr|mais|more|another|otro/.test(q)).length):0;
 const chosen=Array.from({length:Math.min(2,available.length)},(_,i)=>available[(offset+i)%available.length]);
 const examples=chosen.map(t=>{
  const base=t.parts.reduce((sum,[id,g])=>sum+foods[id].kcal*g/100,0);
  const parts=t.parts.map(([id,g])=>({id,g:Math.max(5,Math.round(g*target!/base/5)*5)}));
  const kcal=parts.map(p=>Math.round(foods[p.id].kcal*p.g/100));
  return parts.map((p,i)=>`${p.g} g ${foods[p.id].name[idx]} (≈ ${kcal[i]} kcal)`).join(' + ')+` = ≈ ${kcal.reduce((a,b)=>a+b,0)} kcal`;
 });
 return say(`Aqui vão exemplos de alimentos que somam aproximadamente ${target} kcal:`,`Here are food combinations totalling approximately ${target} kcal:`,`Aquí tienes ejemplos de alimentos que suman aproximadamente ${target} kcal:`)+'\n\n'+examples.map((e,i)=>`${i+1}. ${e}`).join('\n\n')+'\n\n'+say('Pesos dos alimentos prontos para comer. Estimativas da TACO/UNICAMP; óleo e molhos alteram o total. É um exemplo de soma, não uma meta diária. Pode pedir outra combinação ou dizer o que quer substituir.','Weights are for prepared edible food. TACO/UNICAMP estimates; oil and sauces change the total. This illustrates a sum, not a daily target. Ask for another combination or say what you want to replace.','Pesos de alimentos listos para comer. Estimaciones TACO/UNICAMP; aceite y salsas cambian el total. Es un ejemplo de suma, no una meta diaria. Puedes pedir otra combinación o decir qué quieres sustituir.');
}
