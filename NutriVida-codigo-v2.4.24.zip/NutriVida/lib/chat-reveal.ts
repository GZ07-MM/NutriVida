// Only the presentation is progressive; the complete answer is saved first.
export function revealChatAnswer(text:string,update:(text:string)=>void,done:()=>void,reducedMotion=false,host:Pick<typeof globalThis,'setTimeout'|'clearTimeout'>=globalThis){
 const chars=Array.from(text);let index=0,stopped=false,timer:ReturnType<typeof setTimeout>;
 const step=()=>{if(stopped)return;index=Math.min(chars.length,index+Math.max(1,Math.ceil(chars.length/100)));update(chars.slice(0,index).join(''));if(index===chars.length)done();else timer=host.setTimeout(step,30)};
 if(reducedMotion||!text){update(text);done()}else timer=host.setTimeout(step,30);
 return()=>{stopped=true;host.clearTimeout(timer)};
}
