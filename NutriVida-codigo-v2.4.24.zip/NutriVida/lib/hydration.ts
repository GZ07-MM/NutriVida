import type {AppState,Event} from './domain';
export function waterRoutine(settings:Pick<AppState['settings'],'waterCups'|'cupMl'>,events:Event[],day:string){
 const entries=events.filter(e=>e.day===day),hasWater=entries.some(e=>e.kind==='water');
 return {cups:entries.find(e=>e.kind==='water_target')?.amount||(hasWater?10:settings.waterCups||10),ml:entries.find(e=>e.kind==='water_cup_ml')?.amount||(hasWater?200:settings.cupMl||200)};
}
export function waterVolume(events:Event[]){return events.filter(e=>e.kind==='water').reduce((total,e)=>total+e.amount*waterRoutine({},events,e.day).ml,0)}
