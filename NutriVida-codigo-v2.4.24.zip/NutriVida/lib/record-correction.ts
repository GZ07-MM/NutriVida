import type {StoredEvent} from './backup';
export function correctedRecords(records:StoredEvent[],input:{id:string;amount?:number;remove?:boolean},today:string){
 const row=records.find(e=>e.id===input.id);if(!row||row.day>today||!['water','meal','sleep','workout','consumed','spent'].includes(row.kind))throw new Error('Este registro não pode ser corrigido.');
 if(input.remove===true)return records.filter(e=>e.id!==input.id);
 if(!['sleep','consumed','spent'].includes(row.kind)||!Number.isFinite(input.amount)||Number(input.amount)<1||Number(input.amount)>(row.kind==='sleep'?1440:10000)||!Number.isInteger(input.amount))throw new Error('Informe uma quantidade válida.');
 const next=records.map(e=>e.id===input.id?{...e,amount:Number(input.amount)}:e);if(row.kind==='sleep'&&next.filter(e=>e.day===row.day&&e.kind==='sleep').reduce((n,e)=>n+e.amount,0)>1440)throw new Error('O total de sono do dia não pode ultrapassar 24 horas.');return next;
}
