import {createLocalStore, LOCAL_KEY, LOCAL_SIGNED_OUT_KEY} from './local-store';

export const LOCAL_ACCOUNTS_KEY='nutrivida-accounts-v1';
type StoragePort=Pick<Storage,'getItem'|'setItem'|'removeItem'>;
type Account={id:string;email:string;salt:string;password:string;attempts:number;lockedUntil:number};
type Accounts={version:1;active:string|null;accounts:Account[]};
const empty=():Accounts=>({version:1,active:null,accounts:[]});
async function digest(password:string,salt:string){
 const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);
 return Array.from(new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt:new TextEncoder().encode(salt),iterations:100000,hash:'SHA-256'},key,256))).map(n=>n.toString(16).padStart(2,'0')).join('');
}
export function createLocalAccounts(storage:StoragePort,clock=()=>new Date()){
 const read=():Accounts=>{
  const raw=storage.getItem(LOCAL_ACCOUNTS_KEY);if(!raw)return empty();
  try{const value=JSON.parse(raw);if(value.version!==1||!Array.isArray(value.accounts)||!value.accounts.every((a:Account)=>typeof a.id==='string'&&typeof a.email==='string'&&typeof a.salt==='string'&&typeof a.password==='string'))throw new Error();return value}
  catch{throw new Error('Não foi possível ler as contas salvas neste aparelho. Não apague os dados do aplicativo.')}
 };
 const save=(value:Accounts)=>{try{storage.setItem(LOCAL_ACCOUNTS_KEY,JSON.stringify(value))}catch{throw new Error('Não foi possível salvar a conta neste aparelho. Verifique o espaço disponível.')}};
 const current=(value=read())=>value.accounts.find(a=>a.id===value.active);
 const scoped=(id:string):StoragePort=>({getItem:k=>storage.getItem(id+':'+k),setItem:(k,v)=>storage.setItem(id+':'+k,v),removeItem:k=>storage.removeItem(id+':'+k)});
 const legacy=()=>{const raw=storage.getItem(LOCAL_KEY);if(!raw)return null;const state=createLocalStore(storage,clock).initial();return state.data.profile?raw:null};
 const accountRequest=async(method:string,body:unknown)=>{
  const value=read();
  if(method==='GET')return {email:current(value)?.email??null};
  if(method==='DELETE'){save({...value,active:null});return {ok:true}}
  if(method!=='POST')throw new Error('Operação de conta inválida.');
  const b=body as {mode?:string;email?:string;password?:string;currentPassword?:string};
  const email=typeof b?.email==='string'?b.email.trim().toLowerCase():'';
  const password=typeof b?.password==='string'?b.password.replace(/\s/g,''):'';
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>200||password.length<(b.mode==='login'?6:8)||password.length>128||!['create','login','recover'].includes(b.mode??''))throw new Error('Informe um e-mail válido e uma senha de 8 a 128 caracteres, sem espaços.');
  const account=value.accounts.find(a=>a.email===email);
  if(b.mode==='create'){
   if(account)throw new Error('Essa conta já existe. Use Entrar.');
   // Claim the previous APK profile only for the first account, never for later accounts.
   const previous=value.accounts.length===0?legacy():null;
   const id=crypto.randomUUID(),salt=crypto.randomUUID();
   const created:Account={id,email,salt,password:await digest(password,salt),attempts:0,lockedUntil:0};
   if(previous)storage.setItem(id+':'+LOCAL_KEY,previous);
   save({...value,active:id,accounts:[...value.accounts,created]});
   if(previous){try{storage.removeItem(LOCAL_KEY);storage.removeItem(LOCAL_SIGNED_OUT_KEY)}catch{/* The claimed profile remains safely stored under its account. */}}
   return {email};
  }
  if(!account)throw new Error('E-mail ou senha incorretos.');
  if(account.lockedUntil>clock().getTime())throw new Error('Muitas tentativas. Aguarde alguns minutos antes de tentar novamente.');
  const supplied=b.mode==='recover'?b.currentPassword:password;
  if(b.mode==='recover'&&value.active!==account.id)throw new Error('Entre na conta para alterar sua senha. No APK, recuperar pelo e-mail não está disponível.');
  if(typeof supplied!=='string'||await digest(supplied.replace(/\s/g,''),account.salt)!==account.password){
   account.attempts=(account.attempts||0)+1;if(account.attempts>=5)account.lockedUntil=clock().getTime()+300000;save(value);throw new Error('E-mail ou senha incorretos.');
  }
  if(b.mode==='recover'){account.salt=crypto.randomUUID();account.password=await digest(password,account.salt)}
  account.attempts=0;account.lockedUntil=0;value.active=account.id;save(value);return {email};
 };
 const execute=async(url:string,method:string,body?:unknown,owner?:string)=>{
  if(url==='/api/account')return accountRequest(method,body);
  const value=read(),account=current(value);if(!account||account.id!==owner)throw new Error('Entre na sua conta para continuar.');
  const store=createLocalStore(scoped(account.id),clock);
  const result=await store.request(url,method,body);
  if(url==='/api/state'&&method==='DELETE'){
   save({version:1,active:null,accounts:value.accounts.filter(a=>a.id!==account.id)});
   try{storage.removeItem(account.id+':'+LOCAL_SIGNED_OUT_KEY)}catch{}
  }
  return result;
 };
 // Authentication and data writes share a queue; a pending save cannot land in a new account.
 let queue:Promise<unknown>=Promise.resolve();
 const request=(url:string,method='GET',body?:unknown):Promise<any>=>{let owner:string|undefined;try{if(url!=='/api/account')owner=current()?.id}catch(e){return Promise.reject(e)}const result=queue.then(()=>execute(url,method,body,owner));queue=result.catch(()=>{});return result};
 return {request,hasLegacy:()=>read().accounts.length===0&&!!legacy()};
}
