import type {SpeechRecognizer} from './chat-dictation';
export type AndroidDictationBridge={startDictation?:(id:string,language:string)=>void;stopDictation?:(id:string,abort:boolean)=>void;dictationPermissionPending?:()=>boolean};
type NativeEvent={id:string;type:'result'|'error'|'end';text?:string;error?:string};
type NativeHost={NutriVidaAndroid?:AndroidDictationBridge;addEventListener?:EventTarget['addEventListener'];removeEventListener?:EventTarget['removeEventListener']};
let sequence=0;
export function androidSpeechConstructor(host:NativeHost){
 const bridge=host.NutriVidaAndroid;
 if(!bridge?.startDictation||!bridge.stopDictation||!host.addEventListener||!host.removeEventListener)return undefined;
 return class AndroidSpeechRecognizer implements SpeechRecognizer {
  lang='pt-BR';continuous=true;interimResults=true;maxAlternatives=1;
  onresult:SpeechRecognizer['onresult']=null;onerror:SpeechRecognizer['onerror']=null;onend:SpeechRecognizer['onend']=null;
  private id='';
  private receive=(event:Event)=>{
   const value=(event as CustomEvent<NativeEvent>).detail;if(!this.id||value?.id!==this.id)return;
   if(value.type==='result'&&typeof value.text==='string')this.onresult?.({results:[[{transcript:value.text}]]});
   else if(value.type==='error')this.onerror?.({error:value.error||'audio-capture'});
   else if(value.type==='end'){this.detach();this.onend?.()}
  };
  private detach(){host.removeEventListener!('nutrivida-dictation',this.receive);this.id=''}
  start(){if(this.id)return;this.id='voice-'+Date.now()+'-'+(++sequence);host.addEventListener!('nutrivida-dictation',this.receive);try{bridge!.startDictation!(this.id,this.lang)}catch(e){this.detach();throw e}}
  stop(){if(this.id)bridge!.stopDictation!(this.id,false)}
  abort(){const id=this.id;this.detach();if(id)bridge!.stopDictation!(id,true)}
 };
}
