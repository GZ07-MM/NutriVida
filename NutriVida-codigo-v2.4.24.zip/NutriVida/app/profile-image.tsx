'use client';
const images:Record<string,string>={apple:'/avatars/apple.png',fire:'/avatars/fire.webp',balance:'/avatars/balance.webp',star:'/avatars/star.webp'};
export function ProfileImage({id='apple',alt='',className='',priority=false}:{id?:string;alt?:string;className?:string;priority?:boolean}){
 return <img className={'profileImage '+className} src={images[id]||images.apple} alt={alt} width={512} height={512} loading={priority?'eager':'lazy'} decoding="async" draggable={false}/>;
}
