import {readState} from '../../../db/state';
import {sameOrigin,errorResponse} from '../../../db/auth';
import {readBackup} from '../../../lib/backup';
import {replaceRecords} from '../../../db/restore';
export async function POST(request:Request){try{
 sameOrigin(request);const text=await request.text();if(text.length>4000000)return Response.json({error:'A cópia deve ter até 4 MB.'},{status:400});const b=JSON.parse(text);
 if(b.confirmation!=='RESTAURAR'||typeof b.operationId!=='string'||b.operationId.length<8||b.operationId.length>120)return Response.json({error:'Digite RESTAURAR para confirmar a substituição.'},{status:400});
 const c=await readState(request);if(c.data.applied.includes(b.operationId))return Response.json({ok:true});const backup=readBackup(b.backup,c.day);
 if(!await replaceRecords(c,backup.data,backup.records,b.operationId,backup))return Response.json({error:'Seus dados mudaram durante a restauração. Confira a cópia e tente novamente.'},{status:409});return Response.json({ok:true});
}catch(e){if(e instanceof SyntaxError)return Response.json({error:'Arquivo JSON inválido. Nada foi substituído.'},{status:400});if(e instanceof Error&&e.message.includes('cópia'))return Response.json({error:e.message},{status:400});return errorResponse(e)}}
