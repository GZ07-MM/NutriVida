import {sameOrigin,errorResponse} from '../../../db/auth';
import {readState} from '../../../db/state';
import {correctedRecords} from '../../../lib/record-correction';
import {replaceRecords} from '../../../db/restore';
import type {StoredEvent} from '../../../lib/backup';
export async function POST(request:Request){try{
 sameOrigin(request);const b=await request.json() as {id:string;amount?:number;remove?:boolean;operationId:string};if(typeof b.operationId!=='string'||b.operationId.length<8||b.operationId.length>120)return Response.json({error:'Operação inválida.'},{status:400});
 for(let i=0;i<4;i++){const c=await readState(request);if(c.data.applied.includes(b.operationId))return Response.json({ok:true});const rows=await c.db.prepare('SELECT id,day,kind,amount FROM report_events WHERE owner=? ORDER BY day,id').bind(c.owner).all<StoredEvent>();const records=rows.results.map(e=>({...e,id:e.id.slice(c.owner.length+1)}));const corrected=correctedRecords(records,b,c.day);if(await replaceRecords(c,c.data,corrected,b.operationId))return Response.json({ok:true});}
 return Response.json({error:'Houve outra alteração. Tente novamente.'},{status:409});
}catch(e){if(e instanceof Error&&/registro|quantidade/.test(e.message))return Response.json({error:e.message},{status:400});return errorResponse(e)}}
