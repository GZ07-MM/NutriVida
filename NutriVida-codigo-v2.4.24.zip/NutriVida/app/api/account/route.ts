import {env} from 'cloudflare:workers';
import {cookie,errorResponse,hash,passwordHash,platformUser,sameOrigin,session} from '../../../db/auth';
export async function GET(request:Request){try{const {email}=await session(request);return Response.json({email},{headers:{'Cache-Control':'no-store'}})}catch(e){if(e instanceof Error&&e.message==='AUTH')return Response.json({email:null},{headers:{'Cache-Control':'no-store'}});return errorResponse(e)}}
export async function POST(request:Request){try{sameOrigin(request);const user=platformUser(request),db=env.DB;if(!db)throw new Error('DB');const body=await request.json() as {mode:string;email:string;password:string};const email=typeof body.email==='string'?body.email.trim().toLowerCase():'';const password=typeof body.password==='string'?body.password.replace(/\s/g,''):'';if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>200||password.length<(body.mode==='login'?6:8)||password.length>128||!['create','login','recover'].includes(body.mode))return Response.json({error:'Informe um e-mail válido e uma senha de 8 a 128 caracteres, sem espaços.'},{status:400});const owner=await hash(user+':'+email),platform=await hash(user);const row=await db.prepare('SELECT password,salt,attempts,locked_until FROM app_accounts WHERE owner=?').bind(owner).first<{password:string;salt:string;attempts:number;locked_until:number}>();
if(body.mode==='create'){
 if(row)return Response.json({error:'Essa conta já existe. Use Entrar ou Esqueceu sua senha.'},{status:409});
 const salt=crypto.randomUUID(),encodedPassword=await passwordHash(password,salt),token=crypto.randomUUID()+crypto.randomUUID();
 // A duplicate request cannot change an existing password or mint a session.
 const created=await db.batch([
  db.prepare('INSERT OR IGNORE INTO app_accounts(owner,platform_user,email,password,salt,attempts,locked_until,created) VALUES(?,?,?,?,?,0,0,?)').bind(owner,platform,email,encodedPassword,salt,new Date().toISOString()),
  db.prepare('INSERT INTO app_sessions(token,owner,platform_user,email,expires) SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM app_accounts WHERE owner=? AND salt=?)').bind(await hash(token),owner,platform,email,Date.now()+2592000000,owner,salt),
  db.prepare('DELETE FROM email_verifications WHERE owner=? AND EXISTS(SELECT 1 FROM app_accounts WHERE owner=? AND salt=?)').bind(owner,owner,salt)
 ]);
 if(!created[0].meta.changes)return Response.json({error:'Essa conta já existe. Use Entrar ou Esqueceu sua senha.'},{status:409});
 return Response.json({email},{headers:{'Set-Cookie':cookie(token,request),'Cache-Control':'no-store'}});
}
if(!row)return Response.json({error:'E-mail ou senha incorretos.'},{status:401});
if(row&&body.mode==='login'){
if(row.locked_until>Date.now())return Response.json({error:'Muitas tentativas. Aguarde alguns minutos antes de tentar novamente.'},{status:429});
if(await passwordHash(password,row.salt)!==row.password){await db.prepare('UPDATE app_accounts SET attempts=attempts+1,locked_until=CASE WHEN attempts>=4 THEN ? ELSE locked_until END WHERE owner=?').bind(Date.now()+300000,owner).run();return Response.json({error:'E-mail ou senha incorretos.'},{status:401})}}
if(body.mode==='recover'){
 // Recovery is authenticated by the same platform identity that owns this account, never by email alone.
 if(!row)return Response.json({error:'Nenhuma conta encontrada para este acesso.'},{status:404});
 const salt=crypto.randomUUID();await db.batch([db.prepare('UPDATE app_accounts SET password=?,salt=?,attempts=0,locked_until=0 WHERE owner=?').bind(await passwordHash(password,salt),salt,owner),db.prepare('DELETE FROM app_sessions WHERE owner=?').bind(owner)]);
}
await db.prepare('UPDATE app_accounts SET attempts=0,locked_until=0 WHERE owner=?').bind(owner).run();const token=crypto.randomUUID()+crypto.randomUUID();await db.prepare('INSERT INTO app_sessions(token,owner,platform_user,email,expires) VALUES(?,?,?,?,?)').bind(await hash(token),owner,platform,email,Date.now()+2592000000).run();return Response.json({email},{headers:{'Set-Cookie':cookie(token,request),'Cache-Control':'no-store'}})
}catch(e){return errorResponse(e)}}
export async function DELETE(request:Request){try{sameOrigin(request);const {db,owner}=await session(request);const token=request.headers.get('cookie')?.match(/(?:^|;\s*)nv_session=([^;]+)/)?.[1];if(token)await db.prepare('DELETE FROM app_sessions WHERE token=? AND owner=?').bind(await hash(token),owner).run();return Response.json({ok:true},{headers:{'Set-Cookie':cookie('',request,true)}})}catch(e){return errorResponse(e)}}
