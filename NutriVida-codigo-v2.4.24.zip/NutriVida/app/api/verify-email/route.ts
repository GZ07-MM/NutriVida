import {sameOrigin,platformUser,errorResponse} from '../../../db/auth';

export async function POST(request:Request){try{sameOrigin(request);platformUser(request);return Response.json({error:'A confirmação de e-mail não é mais necessária. Crie sua conta diretamente na tela de cadastro.'},{status:410,headers:{'Cache-Control':'no-store'}})}catch(e){return errorResponse(e)}}
