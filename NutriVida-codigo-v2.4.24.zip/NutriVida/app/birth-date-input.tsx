'use client';
import {useLayoutEffect,useRef} from 'react';
import {editBirthDate} from '../lib/birth-date-input';

export function BirthDateInput({value,onChange,label,invalid=false,lang='pt'}:{value:string;onChange:(value:string)=>void;label:string;invalid?:boolean;lang?:string}){
 const input=useRef<HTMLInputElement>(null),caret=useRef<number|null>(null);
 const restoreCaret=()=>{if(caret.current!==null&&input.current&&document.activeElement===input.current){input.current.setSelectionRange(caret.current,caret.current);caret.current=null}};
 useLayoutEffect(restoreCaret);
 return <input ref={input} className="datePickerInput" type="text" inputMode="numeric" autoComplete="bday" placeholder={lang==='en'?'DD/MM/YYYY':'DD/MM/AAAA'} required maxLength={10} pattern="[0-9]{2}/[0-9]{2}/[0-9]{4}" value={value} aria-label={label} aria-invalid={invalid} onChange={e=>{const result=editBirthDate(value,e.currentTarget.value,e.currentTarget.selectionStart||0,(e.nativeEvent as InputEvent).inputType);caret.current=result.caret;onChange(result.text);if(result.text===value)requestAnimationFrame(restoreCaret)}}/>;
}
