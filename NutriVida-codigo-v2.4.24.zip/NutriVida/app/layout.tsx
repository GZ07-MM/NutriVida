import type { Metadata, Viewport } from "next";
import "./globals.css";
import "./future.css";

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
  viewportFit: "cover",
};

export const metadata: Metadata = {
  title: "NutriVida",
  description: "Hábitos hoje, bem-estar sempre.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" data-design="future" suppressHydrationWarning>
      <head><script src="/appearance.js?v=2.4.7" /></head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
