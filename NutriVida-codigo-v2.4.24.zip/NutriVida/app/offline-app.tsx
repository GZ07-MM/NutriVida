'use client';
import {useEffect,useRef,useState} from 'react';
import {AppProvider} from './state';import {Screens} from './screens';import {Logo} from './ui';import {Login} from './login';
import {createLocalAccounts} from '../lib/local-accounts';import {setLocalTransport,setAppDay} from '../lib/progress';import type {AppState} from '../lib/domain';
export default function OfflineApp(){
 const accounts=useRef<ReturnType<typeof createLocalAccounts>|null>(null);
 const [initial,setInitial]=useState<{data:AppState;day:string}|null>(null),[email,setEmail]=useState<string|null>(null),[loading,setLoading]=useState(true),[legacy,setLegacy]=useState(false),[error,setError]=useState('');
 const boot=async()=>{setLoading(true);setError('');try{
  const store=accounts.current;if(!store)throw new Error('Não foi possível abrir as contas locais.');
  const account=await store.request('/api/account');setLegacy(store.hasLegacy());setEmail(account.email);
  if(account.email){const state=await store.request('/api/state');setAppDay(state.day);setInitial(state)}else setInitial(null);
 }catch(e){setError((e as Error).message)}finally{setLoading(false)}};
 useEffect(()=>{try{accounts.current=createLocalAccounts(localStorage);setLocalTransport(accounts.current.request);void boot()}catch(e){setError((e as Error).message);setLoading(false)}
  const deleted=()=>void boot();window.addEventListener('nutrivida-account-deleted',deleted);
  return()=>{window.removeEventListener('nutrivida-account-deleted',deleted);setLocalTransport(null)};
 },[]);
 if(loading)return <main className="auth loadingApp"><Logo/><p role="status">Carregando seu NutriVida…</p></main>;
 if(error)return <main className="auth"><Logo/><p role="alert" className="formError">{error}</p><button className="primary" onClick={()=>void boot()}>Tentar novamente</button></main>;
 if(!email||!initial)return <Login done={boot} offline legacy={legacy}/>;
 return <AppProvider key={email} email={email} initial={initial} onLogout={()=>void boot()}><Screens/></AppProvider>;
}
