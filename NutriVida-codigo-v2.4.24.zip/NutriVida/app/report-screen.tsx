"use client";
import {useState} from "react";
import {TrendingUp,Waves,Utensils,MoonStar,Dumbbell,Target,Flame,LockKeyhole} from "lucide-react";
import {Shell,Top,type Screen} from "./ui";
import {useApp} from "./state";
import {waterVolume} from "../lib/hydration";
import {RecordEditor} from "./record-editor";
import {appDate} from "../lib/progress";
import {monthInfo,shiftMonth,calendarStart} from "../lib/calendar";
export function Reports({setScreen}:{setScreen:(s:Screen)=>void}) {
  const {data,history,refresh,error}=useApp(); const [viewMonth,setViewMonth]=useState(history.day.slice(0,7));const {year,month,days,offset}=monthInfo(viewMonth);const [selectedDay,setSelectedDay]=useState<number|null>(null);const loading=false;
  const now=history?new Date(history.day+"T12:00:00"):appDate();const currentMonth=history.day.slice(0,7),firstMonth=calendarStart(data.created,history.day,history.events);
  const months=["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
  const future=viewMonth>currentMonth;const prefix=viewMonth;
  const events=future?[]:(history?.events||[]).filter(e=>e.day.startsWith(prefix));const sum=(kind:string,day?:number)=>events.filter(e=>e.kind===kind&&(!day||Number(e.day.slice(8))===day)).reduce((total,e)=>total+e.amount,0);
  const minutes=sum("sleep");
  const dailyCounts=Array.from({length:days},(_,i)=>events.filter(e=>Number(e.day.slice(8))===i+1&&!e.kind.startsWith("water_")).reduce((n,e)=>n+(e.kind==="sleep"||e.kind==="consumed"||e.kind==="spent"?1:e.amount),0));const maximum=Math.max(1,...dailyCounts);
  return <Shell screen="reports" setScreen={setScreen}><Top title="Relatórios" subtitle="Acompanhe a evolução dos seus hábitos." icon={TrendingUp} store={()=>setScreen("shop")}/>
    <div className="monthPicker"><button disabled={viewMonth<=firstMonth} aria-label="Mês anterior" onClick={()=>{setViewMonth(shiftMonth(viewMonth,-1));setSelectedDay(null)}}>‹</button><div><h2>{months[month]} {year}</h2><span>Sua retrospectiva do mês</span></div><button disabled={viewMonth>=history.day.slice(0,4)+"-12"} aria-label="Próximo mês" onClick={()=>{setViewMonth(shiftMonth(viewMonth,1));setSelectedDay(null)}}>›</button></div>
    {error?<section className="panel"><p role="alert">{error}</p><button className="primary" onClick={refresh}>Tentar novamente</button></section>:loading?<p role="status">Carregando registros…</p>:<>
    <p className="yearRule">{future?"Este mês ainda não começou.":`Hoje: ${now.toLocaleDateString("pt-BR")}`}</p>
    <div className="reportGrid">{[["Água",`${sum("water")} copos`,Waves,"blue",`${waterVolume(events)} ml`],["Alimentação",`${sum("meal")} ${sum("meal")===1?"refeição":"refeições"}`,Utensils,"orange",""],["Sono",`${Math.floor(minutes/60)}h ${minutes%60}min`,MoonStar,"purple",""],["Treinos",`${sum("workout")} ${sum("workout")===1?"treino":"treinos"}`,Dumbbell,"pink",""],["Metas",`${sum("goal_completed")} concluídas`,Target,"green",`${sum("goal_created")} criadas neste mês`],["Presença",`${sum("presence")} dias`,Flame,"orange","Entradas no app"],["Kcal consumidas",`${sum("consumed")} kcal`,Utensils,"orange","Total informado"],["Kcal gastas",`${sum("spent")} kcal`,Flame,"pink","Total informado"]].map(([a,b,I,t,detail]:any)=><div className={"reportCard "+t} key={a}><I/><span>{a}</span><b>{b}</b>{detail&&<small>{detail}</small>}</div>)}</div>
    <section className="panel reportCalendar"><h2>Dias do mês</h2><div className="reportDays">{["Seg","Ter","Qua","Qui","Sex","Sáb","Dom"].map(d=><small key={d}>{d}</small>)}{Array.from({length:offset},(_,i)=><span key={`blank-${i}`}/>)}{Array.from({length:days},(_,i)=>{const day=i+1;const locked=future||(viewMonth===currentMonth&&day>now.getDate());return <button key={day} disabled={locked} className={(dailyCounts[i]>0?"recorded ":"")+(selectedDay===day?"selected":"")} onClick={()=>setSelectedDay(day)} aria-label={`${day} de ${months[month]}${locked?", ainda não chegou":""}`}>{day}{locked?<LockKeyhole size={12}/>:dailyCounts[i]>0?<i/>:null}</button>})}</div>{selectedDay&&<p>{selectedDay} de {months[month]}: {sum("water",selectedDay)} copos · {sum("meal",selectedDay)} refeições · {sum("workout",selectedDay)} treinos · {Math.floor(sum("sleep",selectedDay)/60)}h {sum("sleep",selectedDay)%60}min de sono · {sum("goal_completed",selectedDay)} metas concluídas · {sum("consumed",selectedDay)} kcal consumidas · {sum("spent",selectedDay)} kcal gastas.</p>}</section>{selectedDay&&<RecordEditor day={`${viewMonth}-${String(selectedDay).padStart(2,"0")}`}/>}
    <section className="panel"><h2>Resumo do mês</h2>{events.length===0?<p>{future?"Aguardando o início deste mês.":"Seus registros aparecerão aqui conforme você usar o app."}</p>:<><div className="chart reportChart" aria-hidden="true">{dailyCounts.map((value,i)=><i key={i} title={`Dia ${i+1}: ${value} registros`} style={{height:value?Math.max(4,value/maximum*100):0}}/>)}</div><p className="hint">Eventos de registro por dia · {months[month]}</p><details className="chartTable"><summary>Ver os dados do gráfico</summary><table><caption>Registros por dia</caption><thead><tr><th scope="col">Dia</th><th scope="col">Registros</th></tr></thead><tbody>{dailyCounts.map((value,i)=><tr key={i}><th scope="row">{i+1}</th><td>{value}</td></tr>)}</tbody></table></details></>}</section>
    </>}
  </Shell>
}

