"use client";
import {useState,useMemo,useEffect,useRef} from "react";
import {Apple,ArrowLeft,ArrowRight,Check,CalendarDays,ChevronRight,Home,Bot,MoonStar,TrendingUp,CircleUserRound,ShoppingBag,Eye,EyeOff,Shield,Star} from "lucide-react";
import {Localized} from "./translations";
export type Screen="login"|"signup"|"home"|"ai"|"sleep"|"reports"|"profile"|"water"|"workouts"|"goals"|"food"|"missions"|"ranks"|"streak"|"shop"|"premium"|"myprofile";
export type Tone="orange"|"blue"|"green"|"pink"|"purple"|"navy";
export const nav=[["Nutri IA","ai",Bot],["Sono","sleep",MoonStar],["Início","home",Home],["Relatórios","reports",TrendingUp],["Perfil","profile",CircleUserRound]] as const;
export function Logo({compact=false}:{compact?:boolean}) {
  return <div className={"logo "+(compact?"compact":"")}>
    <span className="logoMark" aria-label="Símbolo NutriVida">
      <svg className="brandApple" viewBox="0 0 100 100" role="img">
        <path d="M49 28c-5-10-13-14-18-15 5 7 7 12 7 19" fill="none" stroke="currentColor" strokeWidth="7" strokeLinecap="round"/>
        <path d="M52 25c5-15 16-20 29-20-1 14-9 24-26 27" fill="currentColor"/>
        <path d="M50 40c-14-14-40-10-42 13-3 30 18 42 42 43 24-1 45-13 42-43-2-23-28-27-42-13Z" fill="currentColor"/>
        <path d="M7 66h27l6-13 9 28 10-27 7 12h27" fill="none" stroke="#ff7900" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M63 85c4-15 14-22 29-22-2 17-12 27-29 29Z" fill="currentColor"/>
        <path d="M68 86c7-7 12-11 20-16" fill="none" stroke="#ff7900" strokeWidth="3" strokeLinecap="round"/>
      </svg>
    </span>
    <span>Nutri<b>Vida</b></span>
  </div>;
}

export function RankBadge({index=0,locked=false,className=""}:{index?:number;locked?:boolean;className?:string}) {
  const tones=['bronze','bronze','silver','bronze','gold','steel','steel','green','teal','blue','purple','purple','pink','gold','gold','blue','purple','purple','red','gold'];
  return <span className={`rankBadge badge-${tones[Math.min(index,19)]} ${locked?'badge-locked':''} ${className}`} aria-hidden="true"><Shield className="badgeShield"/><Star className="badgeStar"/></span>;
}

export function StoreButton({go}:{go:()=>void}) {
  return <button className="storeBtn" onClick={go} aria-label="Abrir loja"><ShoppingBag/></button>;
}

export function Top({title,subtitle,icon:Icon,tone="navy",back,store}:{title:string;subtitle?:string;icon?:any;tone?:Tone;back?:()=>void;store?:()=>void}) {
  return <Localized><header className="top">
    {back && <button className="roundBtn" onClick={back} aria-label="Voltar"><ArrowLeft/></button>}
    {Icon && <span className={"topIcon "+tone}><Icon/></span>}
    <div className="topText"><h1>{title}</h1>{subtitle&&<p>{subtitle}</p>}</div>
    {store&&<StoreButton go={store}/>}
  </header></Localized>;
}

export function BottomNav({screen,setScreen}:{screen:Screen;setScreen:(s:Screen)=>void}) {
  return <Localized><nav className="bottomNav" aria-label="Navegação principal">{nav.map(([label,target,Icon])=>
    <button key={target} aria-current={screen===target?"page":undefined} className={screen===target?"active":""} onClick={()=>setScreen(target)}>
      <Icon aria-hidden="true"/><span>{label}</span>
    </button>
  )}</nav></Localized>;
}

export function Shell({children,screen,setScreen,navBar=true,className=""}:{children:React.ReactNode;screen:Screen;setScreen:(s:Screen)=>void;navBar?:boolean;className?:string}) {
  const main=useRef<HTMLElement>(null);useEffect(()=>{main.current?.focus({preventScroll:true});window.scrollTo({top:0,behavior:'instant'})},[screen]);
  return <Localized><a className="skipLink" href="#app-content">Ir para o conteúdo</a><main ref={main} id="app-content" tabIndex={-1} className={`app ${navBar?"withNav":""} screen-${screen} ${className}`}>{children}{navBar&&<BottomNav screen={screen} setScreen={setScreen}/>}</main></Localized>;
}

export function Progress({value,tone="orange"}:{value:number;tone?:Tone}) {
  return <div className="progress" role="progressbar" aria-label="Progresso" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(Math.max(0,Math.min(100,value)))}><i className={tone} style={{width:`${Math.max(0,Math.min(100,value))}%`}}/></div>;
}

