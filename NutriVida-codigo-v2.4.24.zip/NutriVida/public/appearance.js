// Apply only display preferences before the first screen is painted.
// Account data and progress continue to come from the authenticated store.
(function () {
  var root = document.documentElement;
  root.dataset.design = 'future';
  try {
    var saved = JSON.parse(localStorage.getItem('nutrivida_appearance') || 'null');
    if (!saved || (saved.theme !== 'light' && saved.theme !== 'dark')) return;
    root.dataset.theme = saved.theme;
    root.dataset.large = saved.largeText === true ? 'true' : 'false';
    root.dataset.motion = saved.reducedMotion === true ? 'reduced' : 'normal';
    if (window.NutriVidaAndroid) window.NutriVidaAndroid.setTheme(saved.theme === 'dark');
  } catch (_) {
    // Storage can be disabled. The signed-in account still restores its settings.
  }
})();
