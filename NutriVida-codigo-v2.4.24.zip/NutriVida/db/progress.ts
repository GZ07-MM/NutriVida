import {session} from './auth';
import {periodBounds,missions,type AppState} from '../lib/domain';
export const localDay=(d:Date)=>d.toLocaleDateString('sv-SE',{timeZone:'America/Sao_Paulo'});
// year=0 marks real dates. Older clocks used a simulated January.
// Convert each owner's records atomically, once, before new activity.
async function migrateCalendar(db:D1Database,owner:string,clock:{started:string;year:number}){
 const offset=Math.round((Date.parse(clock.started)-Date.parse(`${clock.year}-01-01`))/86400000);
 const map=(day:string)=>/^\d{4}-\d{2}-\d{2}$/.test(day)?new Date(Date.parse(day+'T12:00:00Z')+offset*86400000).toISOString().slice(0,10):day;
 const row=await db.prepare('SELECT value FROM app_state WHERE owner=?').bind(owner).first<{value:string}>();
 const commands=[];
 if(row){const data=JSON.parse(row.value) as AppState;data.created=map(data.created);data.journeyStart=map(data.journeyStart);data.goals=data.goals.map(g=>({...g,start:map(g.start),end:periodBounds(map(g.start),g.period).end}));data.claimed=[...new Set(data.claimed.map(key=>{const pos=key.lastIndexOf(':');const m=missions.find(m=>m.id===key.slice(0,pos));return m?m.id+':'+periodBounds(map(key.slice(pos+1)),m.period).start:key}))];commands.push(db.prepare('UPDATE app_state SET value=?,revision=revision+1 WHERE owner=? AND EXISTS(SELECT 1 FROM report_clocks WHERE owner=? AND year>0)').bind(JSON.stringify(data),owner,owner))}
 const mapped="date(day, ? || ' days')";
 for(const table of ['report_events','meal_days'])commands.push(db.prepare(`UPDATE ${table} SET id=replace(id,day,${mapped}),day=${mapped} WHERE owner=? AND EXISTS(SELECT 1 FROM report_clocks WHERE owner=? AND year>0)`).bind(offset,offset,owner,owner));
 commands.push(db.prepare('UPDATE report_clocks SET year=0 WHERE owner=? AND year>0').bind(owner));await db.batch(commands);
}
export async function progressContext(request:Request){const {db,owner}=await session(request),day=localDay(new Date());await db.prepare('INSERT OR IGNORE INTO report_clocks(owner,started,year) VALUES(?,?,0)').bind(owner,day).run();const clock=await db.prepare('SELECT started,year FROM report_clocks WHERE owner=?').bind(owner).first<{started:string;year:number}>();if(!clock)throw new Error('Clock unavailable');if(clock.year>0)await migrateCalendar(db,owner,clock);return {db,owner,day}}
