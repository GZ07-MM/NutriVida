import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
export const reportClocks=sqliteTable("report_clocks",{owner:text("owner").primaryKey(),started:text("started").notNull(),year:integer("year").notNull()});
export const reportEvents=sqliteTable("report_events",{id:text("id").primaryKey(),owner:text("owner").notNull(),day:text("day").notNull(),kind:text("kind").notNull(),amount:real("amount").notNull()});

export const mealPlans=sqliteTable("meal_plans",{owner:text("owner").primaryKey(),times:text("times").notNull()});
export const mealDays=sqliteTable("meal_days",{id:text("id").primaryKey(),owner:text("owner").notNull(),day:text("day").notNull(),times:text("times").notNull()});
export const foodPreferences=sqliteTable("food_preferences",{owner:text("owner").primaryKey(),preferences:text("preferences").notNull()});

export const appAccounts=sqliteTable("app_accounts",{owner:text("owner").primaryKey(),platformUser:text("platform_user").notNull(),email:text("email").notNull(),password:text("password").notNull(),salt:text("salt").notNull(),attempts:integer("attempts").notNull(),lockedUntil:integer("locked_until").notNull(),created:text("created").notNull()});
export const emailVerifications=sqliteTable("email_verifications",{owner:text("owner").primaryKey(),platformUser:text("platform_user").notNull(),email:text("email").notNull(),password:text("password").notNull(),salt:text("salt").notNull(),token:text("token").notNull().unique(),expires:integer("expires").notNull(),sentAt:integer("sent_at").notNull(),ready:integer("ready").notNull()});
export const emailSendLimits=sqliteTable("email_send_limits",{platformUser:text("platform_user").primaryKey(),windowStart:integer("window_start").notNull(),count:integer("count").notNull()});
export const appSessions=sqliteTable("app_sessions",{token:text("token").primaryKey(),owner:text("owner").notNull(),platformUser:text("platform_user").notNull(),email:text("email").notNull(),expires:integer("expires").notNull()});
export const appState=sqliteTable("app_state",{owner:text("owner").primaryKey(),value:text("value").notNull(),revision:integer("revision").notNull(),lastOp:text("last_op").notNull()});
export const feedback=sqliteTable("feedback",{id:text("id").primaryKey(),owner:text("owner").notNull(),body:text("body").notNull(),created:text("created").notNull()});
