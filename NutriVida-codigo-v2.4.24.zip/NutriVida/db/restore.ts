import type {Backup,StoredEvent} from '../lib/backup';
import type {AppState} from '../lib/domain';

type Context={db:D1Database;owner:string;revision:number};
export async function replaceRecords(c:Context,data:AppState,records:StoredEvent[],operationId:string,backup?:Backup){
 const {db,owner,revision}=c,op=crypto.randomUUID(),guard='EXISTS(SELECT 1 FROM app_state WHERE owner=? AND last_op=?)';
 const next={...data,applied:[...data.applied.slice(-199),operationId]};
 const statements=[db.prepare('UPDATE app_state SET value=?,revision=revision+1,last_op=? WHERE owner=? AND revision=?').bind(JSON.stringify(next),op,owner,revision),db.prepare(`DELETE FROM report_events WHERE owner=? AND ${guard}`).bind(owner,owner,op)];
 statements.push(db.prepare(`INSERT INTO report_events(id,owner,day,kind,amount) SELECT ?||':'||json_extract(value,'$.id'),?,json_extract(value,'$.day'),json_extract(value,'$.kind'),json_extract(value,'$.amount') FROM json_each(?) WHERE ${guard}`).bind(owner,owner,JSON.stringify(records),owner,op));
 if(backup){
  for(const table of ['meal_days','meal_plans','food_preferences','feedback'])statements.push(db.prepare(`DELETE FROM ${table} WHERE owner=? AND ${guard}`).bind(owner,owner,op));
  if(backup.times.length)statements.push(db.prepare(`INSERT INTO meal_plans(owner,times) SELECT ?,? WHERE ${guard}`).bind(owner,JSON.stringify(backup.times),owner,op));
  statements.push(db.prepare(`INSERT INTO meal_days(id,owner,day,times) SELECT ?||':'||key,?,key,value FROM json_each(?) WHERE ${guard}`).bind(owner,owner,JSON.stringify(backup.days),owner,op));
  if(backup.preferenceSaved)statements.push(db.prepare(`INSERT INTO food_preferences(owner,preferences) SELECT ?,? WHERE ${guard}`).bind(owner,JSON.stringify(backup.preferences),owner,op));
  statements.push(db.prepare(`INSERT INTO feedback(id,owner,body,created) SELECT ?||':'||json_extract(value,'$.id'),?,json_extract(value,'$.text'),COALESCE(json_extract(value,'$.created'),?) FROM json_each(?) WHERE ${guard}`).bind(owner,owner,new Date().toISOString(),JSON.stringify(backup.feedback),owner,op));
 }
 const result=await db.batch(statements);return result[0].meta.changes>0;
}
