CREATE TABLE `report_clocks` (
	`owner` text PRIMARY KEY NOT NULL,
	`started` text NOT NULL,
	`year` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `report_events` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`day` text NOT NULL,
	`kind` text NOT NULL,
	`amount` real NOT NULL
);
