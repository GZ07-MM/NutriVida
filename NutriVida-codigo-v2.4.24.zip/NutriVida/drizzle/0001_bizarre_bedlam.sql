CREATE TABLE `meal_plans` (
	`owner` text PRIMARY KEY NOT NULL,
	`times` text NOT NULL
);
