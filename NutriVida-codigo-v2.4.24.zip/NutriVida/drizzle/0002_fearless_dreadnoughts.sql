CREATE TABLE `meal_days` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`day` text NOT NULL,
	`times` text NOT NULL
);
