CREATE TABLE `food_preferences` (
	`owner` text PRIMARY KEY NOT NULL,
	`preferences` text NOT NULL
);
