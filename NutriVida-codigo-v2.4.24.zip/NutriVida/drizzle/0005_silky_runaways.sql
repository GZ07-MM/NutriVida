CREATE TABLE `email_send_limits` (
	`platform_user` text PRIMARY KEY NOT NULL,
	`window_start` integer NOT NULL,
	`count` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `email_verifications` (
	`owner` text PRIMARY KEY NOT NULL,
	`platform_user` text NOT NULL,
	`email` text NOT NULL,
	`password` text NOT NULL,
	`salt` text NOT NULL,
	`token` text NOT NULL,
	`expires` integer NOT NULL,
	`sent_at` integer NOT NULL,
	`ready` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `email_verifications_token_unique` ON `email_verifications` (`token`);