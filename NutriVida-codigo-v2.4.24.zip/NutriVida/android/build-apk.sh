#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${NUTRIVIDA_ANDROID_TOOLS:?Informe a pasta das ferramentas Android extraidas}"
: "${NUTRIVIDA_KEYSTORE:?Informe o arquivo de assinatura de avaliacao}"
nutrivida_tools="$(realpath "$NUTRIVIDA_ANDROID_TOOLS")"
export LD_LIBRARY_PATH="$nutrivida_tools/usr/lib:$nutrivida_tools/usr/lib/x86_64-linux-gnu/android:$nutrivida_tools/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
nutrivida_java="$nutrivida_tools/usr/share/java"
nutrivida_build="$nutrivida_tools/usr/lib/android-sdk/build-tools/debian"
rm -rf android/build/assets android/build/classes
rm -f android/build/unsigned.apk android/build/aligned.apk android/build/classes.dex android/build/NutriVida-avaliacao.apk
mkdir -p android/build/classes android/build/assets
# Every release rebuilds the current frontend and native code. Never reuse an old APK.
if [[ -n "${NUTRIVIDA_BASE_APK:-}" ]]; then
 echo 'Atualizacao parcial desativada: gere o APK completo da versao atual.' >&2
 exit 1
fi
node --input-type=module <<'JS'
import {readFileSync} from 'node:fs';
const version=JSON.parse(readFileSync('package.json','utf8')).version;
const manifest=readFileSync('android/AndroidManifest.xml','utf8');
if(manifest.match(/android:versionName="([^"]+)"/)?.[1]!==version)throw Error('Site e APK devem ter a mesma versao antes de compilar.');
JS
node node_modules/vite/bin/vite.js build --config android/vite.config.mjs
java -cp "$nutrivida_java/eclipse-jdt-core-3.32.0.jar" org.eclipse.jdt.internal.compiler.batch.Main -proc:none -1.8 -bootclasspath "$nutrivida_java/com.android.android-23.jar" -d android/build/classes android/src/br/com/nutrivida/avaliacao/MainActivity.java
java -cp "$nutrivida_java/com.android.dx-10.0.0.jar" com.android.dx.command.Main --dex --output=android/build/classes.dex android/build/classes
"$nutrivida_build/aapt" package -f -M android/AndroidManifest.xml -S android/res -A android/build/assets -I "$nutrivida_java/com.android.android-23.jar" -F android/build/unsigned.apk
python3 - <<'PY'
from zipfile import ZipFile,ZIP_DEFLATED
with ZipFile('android/build/unsigned.apk','a',ZIP_DEFLATED) as z:z.write('android/build/classes.dex','classes.dex')
PY
"$nutrivida_build/zipalign" -f 4 android/build/unsigned.apk android/build/aligned.apk
java -jar "$nutrivida_java/apksigner-31.0.2.jar" sign --ks "$NUTRIVIDA_KEYSTORE" --ks-pass pass:android --key-pass pass:android --out android/build/NutriVida-avaliacao.apk android/build/aligned.apk
java -jar "$nutrivida_java/apksigner-31.0.2.jar" verify --verbose android/build/NutriVida-avaliacao.apk
"$nutrivida_build/zipalign" -c 4 android/build/NutriVida-avaliacao.apk
echo 'APK de avaliacao criado em android/build/NutriVida-avaliacao.apk'
