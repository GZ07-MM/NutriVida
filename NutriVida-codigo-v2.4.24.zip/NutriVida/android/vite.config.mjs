import {defineConfig} from 'vite';import react from '@vitejs/plugin-react';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
export default defineConfig({root:path.join(root,'web'),plugins:[react()],base:'/',publicDir:path.join(root,'../public'),build:{outDir:path.join(root,'build/assets'),emptyOutDir:true,target:'es2020'},server:{host:'0.0.0.0',port:4173,strictPort:true,allowedHosts:['terminal.local']}});
