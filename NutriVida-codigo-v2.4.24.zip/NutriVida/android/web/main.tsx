import React from 'react';import {createRoot} from 'react-dom/client';import OfflineApp from '../../app/offline-app';import '../../app/globals.css';import '../../app/future.css';
createRoot(document.getElementById('root')!).render(<OfflineApp/>);
