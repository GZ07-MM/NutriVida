package br.com.nutrivida.avaliacao;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.AlarmClock;
import android.speech.SpeechRecognizer;
import android.speech.RecognizerIntent;
import android.speech.RecognitionListener;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.view.View;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.ArrayList;
import org.json.JSONObject;

/** Offline evaluation build. Only packaged, trusted assets can access the bridge. */
public class MainActivity extends Activity {
 private WebView web;
 private byte[] pendingFile;
 private ValueCallback<Uri[]> pendingChooser;
 private SpeechRecognizer speech;
 private String voiceId="";
 private volatile String pendingVoiceId;
 private String pendingVoiceLanguage;
 private static final String ORIGIN="https://app.nutrivida.local/";
 @Override public void onCreate(Bundle saved){
  super.onCreate(saved);
  getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | 0x10);
  web=new WebView(this);setContentView(web);
  web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(true);
  web.getSettings().setMixedContentMode(0);web.getSettings().setSupportZoom(true);
  web.getSettings().setBuiltInZoomControls(true);web.getSettings().setDisplayZoomControls(false);
  web.addJavascriptInterface(new Bridge(),"NutriVidaAndroid");
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,WebChromeClient.FileChooserParams params){
    if(!view.getUrl().startsWith(ORIGIN))return false;
    if(pendingChooser!=null)pendingChooser.onReceiveValue(null);
    pendingChooser=callback;
    try{Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(intent,42);}catch(Exception e){pendingChooser.onReceiveValue(null);pendingChooser=null;message("Não foi possível abrir o seletor de arquivos.");}
    return true;
   }
  });
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,String url){
    if(url.startsWith(ORIGIN))return false;
    if(url.startsWith("https://")||url.startsWith("http://"))try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){message("Nenhum navegador disponível para abrir o link.");}
    return true;
   }
   @Override public WebResourceResponse shouldInterceptRequest(WebView view,String url){
    if(!url.startsWith(ORIGIN))return empty();
    try{
     String path=Uri.parse(url).getPath();if(path==null||path.equals("/"))path="/index.html";
     if(path.contains("..")||path.contains("\\"))return empty();path=path.substring(1);
     String mime=path.endsWith(".html")?"text/html":path.endsWith(".js")?"application/javascript":path.endsWith(".css")?"text/css":path.endsWith(".svg")?"image/svg+xml":path.endsWith(".png")?"image/png":path.endsWith(".webp")?"image/webp":path.endsWith(".otf")?"font/otf":"application/octet-stream";
     InputStream stream=getAssets().open(path);
     HashMap<String,String> headers=new HashMap<String,String>();
     headers.put("Cache-Control","no-cache");headers.put("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'none'; object-src 'none'; frame-src 'none'");
     return new WebResourceResponse(mime,"UTF-8",200,"OK",headers,stream);
    }catch(Exception e){return empty();}
   }
  });
  web.loadUrl(ORIGIN);
 }
 private WebResourceResponse empty(){return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",new HashMap<String,String>(),new ByteArrayInputStream(new byte[0]));}
 private void message(final String text){runOnUiThread(new Runnable(){public void run(){Toast.makeText(MainActivity.this,text,Toast.LENGTH_LONG).show();}});}
 private void voiceEvent(String id,String type,String text,String error){
  if(web==null||web.getUrl()==null||!web.getUrl().startsWith(ORIGIN))return;
  String payload="{\"id\":"+JSONObject.quote(id)+",\"type\":"+JSONObject.quote(type)+",\"text\":"+JSONObject.quote(text==null?"":text)+",\"error\":"+JSONObject.quote(error==null?"":error)+"}";
  web.evaluateJavascript("window.dispatchEvent(new CustomEvent('nutrivida-dictation',{detail:"+payload+"}))",null);
 }
 private void cancelVoice(boolean notify){
  String id=voiceId;voiceId="";pendingVoiceId=null;pendingVoiceLanguage=null;
  SpeechRecognizer previous=speech;speech=null;
  if(previous!=null){try{previous.cancel();previous.destroy();}catch(Exception ignored){}}
  if(notify&&!id.isEmpty())voiceEvent(id,"end",null,null);
 }
 private void beginVoice(final String id,String language){
  if(!id.equals(voiceId))return;
  if(!SpeechRecognizer.isRecognitionAvailable(this)){voiceEvent(id,"error",null,"service-not-allowed");cancelVoice(true);return;}
  try{
   speech=SpeechRecognizer.createSpeechRecognizer(this);
   speech.setRecognitionListener(new RecognitionListener(){
    private void result(Bundle value,boolean finished){
     if(!id.equals(voiceId))return;
     ArrayList<String> words=value==null?null:value.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
     if(words!=null&&!words.isEmpty())voiceEvent(id,"result",words.get(0),null);
     if(finished)cancelVoice(true);
    }
    public void onReadyForSpeech(Bundle b){}
    public void onBeginningOfSpeech(){}
    public void onRmsChanged(float rms){}
    public void onBufferReceived(byte[] b){}
    public void onEndOfSpeech(){}
    public void onEvent(int type,Bundle b){}
    public void onPartialResults(Bundle b){result(b,false);}
    public void onResults(Bundle b){result(b,true);}
    public void onError(int error){if(!id.equals(voiceId))return;String code=error==SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS?"not-allowed":error==SpeechRecognizer.ERROR_NO_MATCH||error==SpeechRecognizer.ERROR_SPEECH_TIMEOUT?"no-speech":error==SpeechRecognizer.ERROR_NETWORK||error==SpeechRecognizer.ERROR_NETWORK_TIMEOUT?"network":"audio-capture";voiceEvent(id,"error",null,code);cancelVoice(true);}
   });
   Intent intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
   intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
   intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,language);
   intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
   intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1);
   speech.startListening(intent);
  }catch(Exception error){voiceEvent(id,"error",null,"audio-capture");cancelVoice(true);}
 }
 @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){
  super.onRequestPermissionsResult(request,permissions,results);
  if(request!=43)return;String id=pendingVoiceId,language=pendingVoiceLanguage;pendingVoiceId=null;pendingVoiceLanguage=null;
  if(id==null||!id.equals(voiceId))return;
  if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)beginVoice(id,language);
  else{voiceEvent(id,"error",null,"not-allowed");cancelVoice(true);}
 }
 public class Bridge {
  @JavascriptInterface public boolean dictationPermissionPending(){return pendingVoiceId!=null;}
  @JavascriptInterface public void startDictation(final String id,final String language){
   if(id==null||!id.matches("voice-[0-9]+-[0-9]+"))return;
   runOnUiThread(new Runnable(){public void run(){
    if(web==null||web.getUrl()==null||!web.getUrl().startsWith(ORIGIN))return;
    cancelVoice(true);voiceId=id;
    String lang="en-US".equals(language)?"en-US":"es-ES".equals(language)?"es-ES":"pt-BR";
    if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){pendingVoiceId=id;pendingVoiceLanguage=lang;requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},43);return;}
    beginVoice(id,lang);
   }});
  }
  @JavascriptInterface public void stopDictation(final String id,final boolean abort){
   runOnUiThread(new Runnable(){public void run(){
    if(id==null||!id.equals(voiceId))return;
    if(abort||speech==null){cancelVoice(true);return;}
    try{speech.stopListening();}catch(Exception error){cancelVoice(true);}
   }});
  }
  @JavascriptInterface public void setTheme(final boolean dark){
   runOnUiThread(new Runnable(){public void run(){
    int color=dark?0xff0e0919:0xffffffff;
    getWindow().setStatusBarColor(color);getWindow().setNavigationBarColor(color);
    getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | 0x10);
    web.setBackgroundColor(color);
   }});
  }
  @JavascriptInterface public void saveFile(final String name,final String mime,final String base64){
   if(base64==null||base64.length()>16000000){message("Arquivo grande demais para exportar.");return;}
   runOnUiThread(new Runnable(){public void run(){
    try{pendingFile=Base64.decode(base64,Base64.DEFAULT);Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(mime.equals("text/calendar")?"text/calendar":"application/json");intent.putExtra(Intent.EXTRA_TITLE,name.replaceAll("[^a-zA-Z0-9._-]","_"));startActivityForResult(intent,41);}catch(Exception e){pendingFile=null;message("Não foi possível abrir o seletor de arquivos.");}
   }});
  }
  @JavascriptInterface public void openAlarm(final int hours,final int minutes){
   if(hours<0||hours>23||minutes<0||minutes>59)return;
   runOnUiThread(new Runnable(){public void run(){try{Intent intent=new Intent(AlarmClock.ACTION_SET_ALARM);intent.putExtra(AlarmClock.EXTRA_HOUR,hours);intent.putExtra(AlarmClock.EXTRA_MINUTES,minutes);intent.putExtra(AlarmClock.EXTRA_MESSAGE,"NutriVida · Acordar");intent.putExtra(AlarmClock.EXTRA_SKIP_UI,false);startActivity(intent);}catch(Exception e){message("Abra o Relógio do celular e configure o horário de acordar.");}}});
  }
 }
 @Override protected void onActivityResult(int request,int result,Intent data){
  super.onActivityResult(request,result,data);
  if(request==42){if(pendingChooser!=null){Uri selected=result==RESULT_OK&&data!=null?data.getData():null;pendingChooser.onReceiveValue(selected!=null&&"content".equals(selected.getScheme())?new Uri[]{selected}:null);pendingChooser=null;}return;}
  if(request==41){try{if(result==RESULT_OK&&data!=null&&data.getData()!=null&&pendingFile!=null){OutputStream out=getContentResolver().openOutputStream(data.getData());if(out==null)throw new Exception();try{out.write(pendingFile);}finally{out.close();}message("Arquivo salvo.");}}catch(Exception e){message("Não foi possível salvar o arquivo.");}finally{pendingFile=null;}}
 }
 @Override public void onBackPressed(){web.evaluateJavascript("(function(){var d=document.querySelector('[aria-modal=\"true\"]');if(d){var b=d.querySelector('[data-close-dialog],button[aria-label^=\"Fechar\"],button[aria-label^=\"Close\"],button[aria-label^=\"Cerrar\"]');if(b){b.click();return true;}}if(window.nutrividaCanGoBack){window.dispatchEvent(new Event('nutrivida-back'));return true;}return false;})()",new ValueCallback<String>(){public void onReceiveValue(String value){if(!"true".equals(value))moveTaskToBack(true);}});}
 private void resumeChat(){if(web!=null)web.post(new Runnable(){public void run(){if(web!=null)web.evaluateJavascript("window.dispatchEvent(new Event('nutrivida-resume'));window.dispatchEvent(new Event('focus'))",null);}});}
 @Override protected void onPause(){super.onPause();if(pendingVoiceId==null){cancelVoice(true);if(web!=null)web.evaluateJavascript("window.dispatchEvent(new Event('nutrivida-pause'))",null);}if(web!=null)web.onPause();}
 @Override protected void onResume(){super.onResume();if(web!=null){web.onResume();resumeChat();}}
 @Override public void onWindowFocusChanged(boolean focused){super.onWindowFocusChanged(focused);if(focused)resumeChat();}
 @Override protected void onDestroy(){cancelVoice(false);if(pendingChooser!=null){pendingChooser.onReceiveValue(null);pendingChooser=null;}if(web!=null){web.removeJavascriptInterface("NutriVidaAndroid");web.destroy();web=null;}super.onDestroy();}
}
