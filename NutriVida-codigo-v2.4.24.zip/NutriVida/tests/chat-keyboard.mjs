import assert from 'node:assert/strict';
import {followChatKeyboard} from '../lib/chat-keyboard.ts';

function device(withViewport=true){
 const input=new EventTarget(),win=new EventTarget(),document=new EventTarget(),viewport=new EventTarget(),styles=new Map(),classes=new Set(),frames=new Map();let id=0,reveals=0;
 Object.assign(viewport,{height:800,width:390,offsetTop:0,scale:1});
 Object.assign(win,{innerHeight:800,innerWidth:390,visualViewport:withViewport?viewport:null,document:Object.assign(document,{visibilityState:"visible",activeElement:null,documentElement:{style:{setProperty:(key,value)=>styles.set(key,value),removeProperty:key=>styles.delete(key)},classList:{add:key=>classes.add(key),toggle:(key,on)=>on?classes.add(key):classes.delete(key),remove:key=>classes.delete(key)}}}),requestAnimationFrame:callback=>{frames.set(++id,callback);return id},cancelAnimationFrame:key=>frames.delete(key)});
 input.value="rascunho preservado";input.blur=()=>{win.document.activeElement=null;input.dispatchEvent(new Event("blur"))};
 const flush=()=>{const tasks=[...frames.values()];frames.clear();tasks.forEach(callback=>callback())};
 const emit=(target,type)=>{target.dispatchEvent(new Event(type));flush()};
 const dispose=followChatKeyboard(win,input,()=>reveals++);
 return {win,input,viewport,styles,classes,frames,emit,flush,dispose,reveals:()=>reveals,focus(){win.document.activeElement=input;emit(input,'focus')}};
}
const overlay=device();assert(overlay.classes.has('chatScreen'));assert.equal(overlay.styles.get('--chat-viewport-height'),'800px');overlay.focus();assert(!overlay.classes.has('chatKeyboard'));
overlay.viewport.height=520;overlay.emit(overlay.viewport,'resize');assert(overlay.classes.has('chatKeyboard'));assert.equal(overlay.styles.get('--chat-keyboard-inset'),'280px');assert.equal(overlay.reveals(),1);
overlay.viewport.height=500;overlay.emit(overlay.viewport,'resize');assert.equal(overlay.styles.get('--chat-keyboard-inset'),'300px');
const beforeScroll=overlay.reveals();overlay.viewport.offsetTop=20;overlay.emit(overlay.viewport,'scroll');assert.equal(overlay.styles.get('--chat-keyboard-inset'),'280px');assert.equal(overlay.reveals(),beforeScroll);
overlay.viewport.offsetTop=0;overlay.viewport.height=800;overlay.emit(overlay.viewport,'resize');assert(!overlay.classes.has('chatKeyboard'));assert.equal(overlay.styles.get('--chat-keyboard-inset'),'0px');

const resized=device();resized.focus();resized.win.innerHeight=500;resized.viewport.height=500;resized.emit(resized.win,'resize');assert(resized.classes.has('chatKeyboard'));assert.equal(resized.styles.get('--chat-keyboard-inset'),'0px');
resized.win.innerHeight=800;resized.viewport.height=800;resized.emit(resized.viewport,'resize');assert(!resized.classes.has('chatKeyboard'));
resized.viewport.scale=2;resized.viewport.height=400;resized.viewport.width=195;resized.emit(resized.viewport,'resize');assert(!resized.classes.has('chatKeyboard'));
resized.viewport.scale=1;resized.viewport.height=800;resized.viewport.width=390;resized.emit(resized.viewport,'resize');
resized.win.innerHeight=390;resized.viewport.height=390;resized.viewport.width=800;resized.win.innerWidth=800;resized.emit(resized.win,'orientationchange');assert(!resized.classes.has('chatKeyboard'));

const fallback=device(false);fallback.focus();fallback.win.innerHeight=480;fallback.emit(fallback.win,'resize');assert(fallback.classes.has('chatKeyboard'));
fallback.win.innerHeight=800;fallback.emit(fallback.win,'resize');assert(!fallback.classes.has('chatKeyboard'));

// The actual controller drives a continuous composer position through every
// intermediate keyboard frame, including the former 120px mode-switch jump.
for(const nav of [106,137,187])for(const adjustResize of [false,true]){
 const animated=device();animated.focus();
 const position=()=>Number.parseFloat(animated.styles.get('--chat-viewport-height'))-Math.max(12,nav-Number.parseFloat(animated.styles.get('--chat-keyboard-height')));
 let previous=position();
 for(const reduction of [20,60,90,119,120,121,150,240,320]){
  animated.viewport.height=800-reduction;if(adjustResize)animated.win.innerHeight=800-reduction;
  animated.emit(animated.viewport,'resize');const current=position();
  assert(current<=previous,'Opening the keyboard must never send the composer downward');
  assert(current<=animated.viewport.height-12,'Composer must stay above the keyboard');previous=current;
 }
 animated.win.document.activeElement=null;animated.emit(animated.input,'blur');
 for(const reduction of [240,150,121,120,119,90,60,20,0]){
  animated.viewport.height=800-reduction;if(adjustResize)animated.win.innerHeight=800-reduction;
  animated.emit(animated.viewport,'resize');const current=position();
  assert(current>=previous,'Closing the keyboard must never send the composer upward');previous=current;
 }
 assert.equal(position(),800-nav);assert(!animated.classes.has('chatKeyboard'));animated.dispose();
}
const jitter=device();jitter.focus();jitter.viewport.height=679;jitter.emit(jitter.viewport,'resize');
for(const height of [680,681,678,682]){jitter.viewport.height=height;jitter.emit(jitter.viewport,'resize');assert(jitter.classes.has('chatKeyboard'),'Intermediate resize events must not toggle navigation back and forth')}
// Duplicate window and visual viewport events share one frame and one scroll.
const beforeDuplicate=jitter.reveals();jitter.viewport.height=500;jitter.win.dispatchEvent(new Event('resize'));jitter.viewport.dispatchEvent(new Event('resize'));assert.equal(jitter.frames.size,1);jitter.flush();assert.equal(jitter.reveals(),beforeDuplicate+1);
jitter.emit(jitter.viewport,'resize');assert.equal(jitter.reveals(),beforeDuplicate+1);
// Backgrounding while typing must not retain the old keyboard/pan on return.
for(const pauseEvent of ['pagehide','nutrivida-pause','visibilitychange']){
 const restore=device();restore.focus();restore.viewport.height=500;restore.viewport.offsetTop=25;restore.emit(restore.viewport,'resize');assert(restore.classes.has('chatKeyboard'));
 restore.viewport.dispatchEvent(new Event('resize'));assert.equal(restore.frames.size,1);
 if(pauseEvent==='visibilitychange'){restore.win.document.visibilityState='hidden';restore.emit(restore.win.document,pauseEvent)}else restore.emit(restore.win,pauseEvent);
 assert.equal(restore.frames.size,0);assert(!restore.classes.has('chatKeyboard'));assert.equal(restore.win.document.activeElement,null);assert.equal(restore.input.value,'rascunho preservado');
 restore.viewport.height=0;restore.win.innerHeight=0;restore.emit(restore.viewport,'resize');assert(!restore.styles.has('--chat-viewport-height'),'Background bounds cannot overwrite the viewport');
 restore.win.innerHeight=800;restore.viewport.height=800;restore.viewport.offsetTop=100;
 restore.win.document.visibilityState='visible';restore.emit(pauseEvent==='visibilitychange'?restore.win.document:restore.win,pauseEvent==='visibilitychange'?'visibilitychange':pauseEvent==='pagehide'?'pageshow':'nutrivida-resume');
 assert.equal(restore.styles.get('--chat-viewport-height'),'800px');assert.equal(restore.styles.get('--chat-viewport-top'),'0px');assert.equal(restore.styles.get('--chat-keyboard-height'),'0px');assert(!restore.classes.has('chatKeyboard'));
 for(let i=0;i<6;i++)restore.flush();assert.equal(restore.frames.size,0,'Recovery is bounded, not an animation loop');restore.dispose();
}
const rotated=device();rotated.focus();rotated.viewport.height=480;rotated.emit(rotated.viewport,'resize');rotated.emit(rotated.win,'nutrivida-pause');rotated.win.innerHeight=390;rotated.viewport.height=390;rotated.viewport.width=800;rotated.win.innerWidth=800;rotated.emit(rotated.win,'nutrivida-resume');assert(!rotated.classes.has('chatKeyboard'));assert.equal(rotated.styles.get('--chat-viewport-height'),'390px');rotated.dispose();
const cold=device();cold.viewport.offsetTop=120;cold.emit(cold.win,'pageshow');assert.equal(cold.styles.get('--chat-viewport-top'),'0px','Cold start never restores a stale keyboard pan');cold.dispose();
const delayed=device();delayed.emit(delayed.win,'nutrivida-pause');delayed.win.innerHeight=0;delayed.viewport.height=0;delayed.emit(delayed.win,'nutrivida-resume');assert(!delayed.styles.has('--chat-viewport-height'));delayed.win.innerHeight=800;delayed.viewport.height=800;delayed.flush();assert.equal(delayed.styles.get('--chat-viewport-height'),'800px');delayed.dispose();
const permission=device();permission.focus();permission.viewport.height=500;permission.emit(permission.viewport,'resize');permission.win.NutriVidaAndroid={dictationPermissionPending:()=>true};permission.emit(permission.win,'nutrivida-pause');assert.equal(permission.win.document.activeElement,permission.input,'A microphone permission prompt must preserve input focus');permission.emit(permission.win,'nutrivida-resume');assert(permission.classes.has('chatKeyboard'),'The microphone permission dialog cannot reset an open keyboard baseline');assert.equal(permission.styles.get('--chat-keyboard-height'),'300px');permission.dispose();
const bounds=device();const validHeight=bounds.styles.get('--chat-viewport-height');bounds.win.innerHeight=0;bounds.viewport.height=0;bounds.emit(bounds.viewport,'resize');assert.equal(bounds.styles.get('--chat-viewport-height'),validHeight);bounds.dispose();
for(const test of [overlay,resized,fallback,jitter]){test.win.dispatchEvent(new Event('resize'));assert(test.frames.size>0);test.dispose();assert.equal(test.frames.size,0);assert(!test.classes.has('chatKeyboard'));assert(!test.styles.has('--chat-keyboard-inset'));assert(!test.styles.has('--chat-keyboard-height'));assert(!test.classes.has('chatScreen'));assert(!test.styles.has('--chat-viewport-height'));assert(!test.styles.has('--chat-viewport-top'));test.emit(test.win,'resize');assert.equal(test.frames.size,0)}
console.log('PASS: continuous keyboard movement, background/return, native pause/resume, cold start, rotation while hidden, delayed/zero viewport, preserved draft, permission prompt, bounded recovery and cleanup');
