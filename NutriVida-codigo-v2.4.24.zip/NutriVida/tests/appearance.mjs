import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';

const script=readFileSync('public/appearance.js','utf8');
function open(raw,blocked=false){
 const root={dataset:{}},calls=[];
 runInNewContext(script,{document:{documentElement:root},localStorage:{getItem(){if(blocked)throw new Error('Storage disabled');return raw}},window:{NutriVidaAndroid:{setTheme(dark){calls.push(dark)}}}});
 return {root,calls};
}
const saved=JSON.stringify({theme:'dark',largeText:true,reducedMotion:true});
for(let reopen=0;reopen<3;reopen++){
 const {root,calls}=open(saved);
 assert.deepEqual(root.dataset,{design:'future',theme:'dark',large:'true',motion:'reduced'});
 assert.deepEqual(calls,[true]);
}
assert.deepEqual(open(JSON.stringify({theme:'light',largeText:false,reducedMotion:false})).root.dataset,{design:'future',theme:'light',large:'false',motion:'normal'});
for(const raw of [null,'broken','null','{}',JSON.stringify({theme:'system'})])assert.deepEqual(open(raw).root.dataset,{design:'future'});
assert.deepEqual(open(saved,true).root.dataset,{design:'future'});
console.log('PASS: appearance restored on cold start and reopening; light/dark, accessibility, blocked/corrupt storage and Android theme bridge');
