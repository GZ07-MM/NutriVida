import assert from 'node:assert/strict';
import {visibleChat,chatCommitted} from '../lib/chat-view.ts';
import {followChatScroll} from '../lib/chat-scroll.ts';

const history=[{role:'user',text:'Água'},{role:'assistant',text:'Resposta anterior'}];
const pending={text:'  Água  ',baseline:JSON.stringify(history)};
assert.deepEqual(visibleChat(history,pending),[...history,{role:'user',text:'Água'}]);
const answered={...pending,answer:'Resposta nova'};
assert.deepEqual(visibleChat(history,answered),[...history,{role:'user',text:'Água'},{role:'assistant',text:'Resposta nova'}]);
const committed=[...history,{role:'user',text:'Água'},{role:'assistant',text:'Resposta nova'}];
assert(chatCommitted(committed,answered));assert.deepEqual(visibleChat(committed,answered),committed);
assert(!chatCommitted(history,{...pending,answer:'Resposta anterior'}));
assert.deepEqual(visibleChat(history,null),history);
const capped=Array.from({length:30},()=>[{role:'user',text:'Água'},{role:'assistant',text:'Resposta anterior'}]).flat();
assert.equal(visibleChat(capped,{text:'Água',baseline:JSON.stringify(capped),answer:'Resposta anterior'}).length,60);

const win=new EventTarget(),calls=[];let bottom=650;
const end={getBoundingClientRect:()=>({bottom}),scrollIntoView:options=>calls.push(options)};
const composer={getBoundingClientRect:()=>({top:700})};
const scroll=followChatScroll(win,end,composer);scroll.reveal('smooth');assert.equal(calls.length,1);
bottom=1600;win.dispatchEvent(new Event('scroll'));scroll.reveal('smooth');scroll.reveal('instant');assert.equal(calls.length,1);
bottom=650;win.dispatchEvent(new Event('scroll'));bottom=900;scroll.reveal('smooth');assert.equal(calls.length,2);
bottom=1600;win.dispatchEvent(new Event('scroll'));scroll.reveal('instant',true);assert.equal(calls.length,3);
scroll.reveal('auto');assert.equal(calls.length,4);assert.equal(calls.at(-1).behavior,'auto');
scroll.dispose();scroll.reveal('smooth',true);assert.equal(calls.length,4);
// A contained chat must scroll its history without scrolling the outside page.
const container=new EventTarget(),insideCalls=[];
Object.assign(container,{scrollHeight:1800,clientHeight:500,scrollTop:1300,scrollTo:options=>insideCalls.push(options)});
const contained=followChatScroll(win,end,composer,container);
contained.reveal('instant',true);assert.deepEqual(insideCalls.at(-1),{top:1300,behavior:'instant'});assert.equal(calls.length,4);
container.scrollTop=200;container.dispatchEvent(new Event('scroll'));contained.reveal('smooth');assert.equal(insideCalls.length,1);
container.scrollTop=1300;container.dispatchEvent(new Event('scroll'));container.clientHeight=300;contained.reveal('instant');assert.equal(insideCalls.at(-1).top,1500);
contained.dispose();contained.reveal('smooth',true);assert.equal(insideCalls.length,2);
console.log('PASS: immediate outgoing message, pending response, server reconciliation without duplicates, repeated questions, history cap, manual reading, bottom follow and reduced motion');
