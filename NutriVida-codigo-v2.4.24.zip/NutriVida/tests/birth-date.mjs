import assert from 'node:assert/strict';
import {editBirthDate} from '../lib/birth-date-input.ts';
let text='';const states=[];
for(const digit of '16112010'){const raw=text+digit;const result=editBirthDate(text,raw,raw.length,'insertText');text=result.text;assert.equal(result.caret,text.length);states.push(text)}
assert.deepEqual(states,['1','16/','16/1','16/11/','16/11/2','16/11/20','16/11/201','16/11/2010']);
assert.deepEqual(editBirthDate('','16/11/2010',10,'insertFromPaste'),{text:'16/11/2010',caret:10});
assert.deepEqual(editBirthDate('','2010-11-16',10,'insertReplacementText'),{text:'16/11/2010',caret:10});
text='16/11/2010';while(text){const raw=text.slice(0,-1);const result=editBirthDate(text,raw,raw.length,'deleteContentBackward');assert(result.text.length<text.length);text=result.text}
assert.deepEqual(editBirthDate('16/11/2010','1611/2010',2,'deleteContentBackward'),{text:'11/12/010',caret:1});
assert.deepEqual(editBirthDate('16/11/2010','1611/2010',2,'deleteContentForward'),{text:'16/12/010',caret:3});
assert.deepEqual(editBirthDate('16/11/2010','16/12/2010',5,'insertText'),{text:'16/12/2010',caret:6});
assert.deepEqual(editBirthDate('','nasci dia 16/11/2010','nasci dia 16/11/2010'.length,'insertFromPaste'),{text:'16/11/2010',caret:10});
console.log('PASS: numeric birth-date typing, automatic separators, paste/autofill, middle edits and backspace to empty');
