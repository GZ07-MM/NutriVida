import assert from 'node:assert/strict';
import {resizeChatComposer} from '../lib/chat-composer.ts';
const values=new Map(),root={style:{setProperty:(key,value)=>values.set(key,value)}};
const field={scrollHeight:44,style:{}};
resizeChatComposer(field,root);assert.equal(field.style.height,'44px');assert.equal(values.get('--chat-composer-extra'),'0px');
field.scrollHeight=88;resizeChatComposer(field,root);assert.equal(field.style.height,'88px');assert.equal(values.get('--chat-composer-extra'),'44px');
field.scrollHeight=220;resizeChatComposer(field,root);assert.equal(field.style.height,'132px');assert.equal(field.style.overflowY,'auto');
field.scrollHeight=44;resizeChatComposer(field,root);assert.equal(field.style.height,'44px');assert.equal(field.style.overflowY,'hidden');assert.equal(values.get('--chat-composer-extra'),'0px');
console.log('PASS: multiline composer grows, caps its height, scrolls long drafts and shrinks after sending');
