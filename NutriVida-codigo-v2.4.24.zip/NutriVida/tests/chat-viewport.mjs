import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const css=readFileSync('app/globals.css','utf8');
const block=css.match(/html\.chatScreen \.screen-ai\.app\{([^}]+)\}/)?.[1];
assert(block,'The chat viewport rule must exist');
const declarations=Object.fromEntries(block.split(';').filter(Boolean).map(value=>{const colon=value.indexOf(':');return [value.slice(0,colon).trim(),value.slice(colon+1).trim()]}));
assert.equal(declarations.height,'var(--chat-viewport-height,100dvh)');
assert.equal(declarations['max-height'],'var(--chat-viewport-height,100dvh)');
assert.equal(declarations['--chat-composer-bottom'],'max(12px,calc(var(--chat-nav-clearance,106px) - var(--chat-keyboard-height,0px)))');
assert.equal(declarations['padding-bottom'],'calc(var(--chat-composer-bottom) + var(--chat-composer-height,62px) + 24px)');
assert(css.includes('html.chatScreen .screen-ai.app .composer{position:absolute;bottom:var(--chat-composer-bottom)}'));
assert(!/html\.chatKeyboard[^{}]*\.composer\{[^}]*bottom:/.test(css),'Keyboard state must not introduce a second, discontinuous composer offset');
// An inherited .app min-height:100vh wins over BOTH height and max-height.
// Reproduce the two screenshot states, plus larger navigation and drafts.
for(const {layout,visible,keyboard,nav,field} of [
 {layout:736,visible:688,keyboard:false,nav:79,field:62},
 {layout:736,visible:420,keyboard:true,nav:79,field:62},
 {layout:800,visible:480,keyboard:true,nav:110,field:146},
 {layout:900,visible:850,keyboard:false,nav:110,field:146},
]){
 const min=declarations['min-height']==='0'?0:layout;
 const actualHeight=Math.max(min,Math.min(visible,visible));
 const clearance=Math.max(12,nav+12+15-(keyboard?layout-visible:0));
 const fieldBottom=actualHeight-clearance,fieldTop=fieldBottom-field;
 assert.equal(actualHeight,visible,'Chat must shrink to the visible viewport, despite the generic .app minimum');
 assert(fieldTop>=0&&fieldBottom<=visible,'The complete composer must remain above the keyboard');
 if(!keyboard)assert.equal(visible-12-nav-fieldBottom,15,'Composer must clear the full navigation by 15px');
}
console.log('PASS: viewport sizing overrides legacy 100vh minimum; screenshot overlap and hidden-composer regressions');
