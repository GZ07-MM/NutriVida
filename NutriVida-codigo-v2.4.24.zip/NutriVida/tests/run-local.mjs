import {spawn,spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import path from 'node:path';
// Generated Worker config is under dist; explicitly resolve local migration paths.
const config=JSON.parse(readFileSync('dist/server/wrangler.json','utf8'));
config.main=path.resolve('dist/server',config.main);config.assets.directory=path.resolve('dist/server',config.assets.directory);
config.d1_databases=config.d1_databases.map(db=>({...db,migrations_dir:path.resolve('drizzle')}));
mkdirSync('.sites-runtime',{recursive:true});writeFileSync('.sites-runtime/local-test-wrangler.json',JSON.stringify(config));
const migrated=spawnSync(process.execPath,['--import','./scripts/sites-env.mjs','./node_modules/wrangler/bin/wrangler.js','d1','migrations','apply','DB','--local','--persist-to','.wrangler/state','--config','.sites-runtime/local-test-wrangler.json'],{stdio:'inherit'});
if(migrated.status!==0)process.exit(migrated.status||1);
const server=spawn(process.execPath,['--import','./scripts/sites-env.mjs','./node_modules/wrangler/bin/wrangler.js','dev','--config','dist/server/wrangler.json','--local','--persist-to','.wrangler/state','--ip','127.0.0.1','--port','4180','--inspector-port','0'],{stdio:['ignore','pipe','pipe']});
let output='';server.stdout.on('data',c=>output=(output+c).slice(-10000));server.stderr.on('data',c=>output=(output+c).slice(-10000));
try{await new Promise((resolve,reject)=>{const deadline=Date.now()+30000;const t=setInterval(()=>{if(output.includes('Ready on')){clearInterval(t);resolve()}else if(Date.now()>deadline){clearInterval(t);reject(new Error(output))}},250);server.once('exit',code=>{clearInterval(t);reject(new Error('Local Worker exited '+code+' '+output))})});console.log('Local Worker ready; running acceptance tests');const test=spawn(process.execPath,['tests/api.mjs'],{stdio:'inherit'});const code=await new Promise(resolve=>test.once('exit',resolve));process.exitCode=code||0;if(code)console.error(output);}catch(e){console.error(String(e));process.exitCode=1}finally{server.kill('SIGTERM');await new Promise(resolve=>server.once('exit',resolve))}
