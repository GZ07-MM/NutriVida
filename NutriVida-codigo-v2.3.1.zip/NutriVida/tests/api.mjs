import assert from 'node:assert/strict';
import {createHash,pbkdf2Sync} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';import {readFileSync,readdirSync} from 'node:fs';import {join} from 'node:path';
function localData(owner,change){const root='.wrangler/state/v3/d1/miniflare-D1DatabaseObject';for(const filename of readdirSync(root).filter(f=>f.endsWith('.sqlite')&&f!=='metadata.sqlite')){const db=new DatabaseSync(join(root,filename));try{const row=db.prepare('SELECT value FROM app_state WHERE owner=?').get(owner);if(row){const data=JSON.parse(row.value);change(data,db);db.prepare('UPDATE app_state SET value=?,revision=revision+1 WHERE owner=?').run(JSON.stringify(data),owner);db.close();return}}catch(e){db.close();throw e}db.close()}throw new Error('Local test state not found')}

const base=process.env.NV_TEST_BASE||'http://127.0.0.1:4180';
if(!/^http:\/\/(127\.0\.0\.1|localhost):/.test(base))throw new Error('Acceptance tests run only against a local Worker.');
const platform='nv-tests-'+crypto.randomUUID(),email=`test-${crypto.randomUUID()}@example.com`,password='TestPassword123';
let cookie='';let checks=0;
async function api(path,method='GET',body,expected=200,headers={}){const response=await fetch(base+path,{method,signal:AbortSignal.timeout(15000),headers:{'Content-Type':'application/json','oai-authenticated-user-id':platform,...(cookie?{Cookie:cookie}:{}),...headers},body:body===undefined?undefined:JSON.stringify(body)});const data=await response.json();assert.equal(response.status,expected,`${method} ${path}: ${JSON.stringify(data)}`);const c=response.headers.get('set-cookie');if(c)cookie=c.split(';')[0];checks++;if(checks%20===0)console.log(`Validated ${checks} API operations`);return data}
const action=(action,value,id=crypto.randomUUID(),status=200)=>api('/api/state','POST',{action,value,id},status);
await api('/api/progress','GET',undefined,401);
await api('/api/account','POST',{mode:'create',email,password:'short'},400);
await api('/api/account','POST',{mode:'create',email,password},503);
await api('/api/account','POST',{mode:'login',email,password,legacyHash:createHash('sha256').update(password).digest('hex')},401);
assert.equal((await api('/api/account')).email,null);
// A local delivery fixture models receipt without adding a production bypass or sending real mail.
const verificationToken=crypto.randomUUID()+crypto.randomUUID();
for(const file of readdirSync('.wrangler/state/v3/d1/miniflare-D1DatabaseObject').filter(f=>f.endsWith('.sqlite')&&f!=='metadata.sqlite')){
 const fixture=new DatabaseSync(join('.wrangler/state/v3/d1/miniflare-D1DatabaseObject',file));
 if(fixture.prepare("SELECT name FROM sqlite_master WHERE name='app_accounts'").get()){
  fixture.exec(readFileSync('drizzle/0005_silky_runaways.sql','utf8').replaceAll('CREATE TABLE ','CREATE TABLE IF NOT EXISTS ').replaceAll('CREATE UNIQUE INDEX ','CREATE UNIQUE INDEX IF NOT EXISTS '));
  const salt=crypto.randomUUID();fixture.prepare('INSERT INTO email_verifications(owner,platform_user,email,password,salt,token,expires,sent_at,ready) VALUES(?,?,?,?,?,?,?,?,1)').run(createHash('sha256').update(platform+':'+email).digest('hex'),createHash('sha256').update(platform).digest('hex'),email,pbkdf2Sync(password,salt,100000,32,'sha256').toString('hex'),salt,createHash('sha256').update(verificationToken).digest('hex'),Date.now()+1800000,Date.now());fixture.close();break;
 }fixture.close();
}
await api('/api/verify-email','POST',{token:verificationToken},410,{'oai-authenticated-user-id':'wrong-identity'});
await api('/api/verify-email','POST',{token:verificationToken});
await api('/api/verify-email','POST',{token:verificationToken},410);
const initial=await api('/api/state');assert.equal(initial.data.gems,0);assert.equal(initial.data.rankXP,0);assert.equal(initial.data.levelXP,0);assert.equal(initial.day,new Date().toLocaleDateString('sv-SE',{timeZone:'America/Sao_Paulo'}));
const p={name:'Test Person',dob:'2010-01-01',height:.95,weight:70,gender:'Outro',activity:'Sedentário',goal:'Criar hábitos equilibrados',lang:'pt'};
await action('profile',{...p,name:''},undefined,400);await action('profile',p);
await action('buy','blue',undefined,400);
const first=await api('/api/progress','POST',{kind:'presence',amount:1,id:'presence'});await api('/api/progress','POST',{kind:'presence',amount:1,id:'presence'});
let h=await api('/api/progress');assert.equal(h.events.find(e=>e.kind==='presence').amount,1);
for(let i=0;i<13;i++)await api('/api/progress','POST',{kind:'water',amount:1,id:'cup-'+i});h=await api('/api/progress');assert.equal(h.events.find(e=>e.kind==='water').amount,10);
await api('/api/progress','POST',{kind:'water',amount:2,id:'cheat'},400);
await action('claim',{mission:'d-water',day:initial.day});await action('claim',{mission:'d-water',day:initial.day},undefined,400);
let state=await api('/api/state');assert.equal(state.data.gems,10);assert.equal(state.data.rankXP,20);
await action('claim',{mission:'d-workout',day:initial.day},undefined,400);
await api('/api/meal-plan','PUT',{times:['08:00','12:00','18:00']},400);await api('/api/meal-plan','PUT',{times:['08:00','12:00','16:00','19:00']});for(let slot=0;slot<4;slot++)await api('/api/meal-plan','POST',{slot});await api('/api/meal-plan','POST',{slot:0});await api('/api/meal-plan','POST',{slot:4},400);h=await api('/api/progress');assert.equal(h.events.find(e=>e.kind==='meal').amount,4);
const prefs={avoid:['milk','eggs'],excluded:['banana'],diet:'vegan'};await api('/api/food-preferences','PUT',prefs);assert.deepEqual((await api('/api/food-preferences')).preferences,prefs);
await api('/api/food-preferences','PUT',{...prefs,avoid:['unknown']},400);
const practical={...prefs,budget:'low',maxMinutes:15,pantry:['banana','tapioca'],pantryOnly:true};await api('/api/food-preferences','PUT',practical);assert.deepEqual((await api('/api/food-preferences')).preferences,practical);await api('/api/food-preferences','PUT',{...practical,maxMinutes:-1},400);await api('/api/food-preferences','PUT',{...practical,pantry:['']},400);
await action('claim',{mission:'d-calorie-deficit',day:initial.day},undefined,400);
const gid=crypto.randomUUID();await action('goal-create',{title:'Walk daily',target:2.5,unit:'km',period:'daily'},gid);await action('goal-create',{title:'Walk daily',target:2.5,unit:'km',period:'daily'},gid);state=await api('/api/state');assert.equal(state.data.goals.length,1);
await action('goal-progress',{id:gid,amount:1});await action('goal-progress',{id:gid,amount:1.5});await action('goal-cancel',gid,undefined,400);await action('goal-archive',gid);h=await api('/api/progress');assert.equal(h.events.find(e=>e.kind==='goal_completed').amount,1);
await action('sleep-log',{sleep:'22:30',wake:'06:30'});await action('sleep-log',{sleep:'22:30',wake:'06:30'},undefined,400);h=await api('/api/progress');assert.equal(h.events.find(e=>e.kind==='sleep').amount,480);
await action('settings',{alarm:true,sleep:'22:30',wake:'22:30'},undefined,400);
await action('workout-start',{body:'Peito',reps:12,sets:1,rounds:1,duration:30,selected:[0]});await action('workout-next',undefined,undefined,400);await action('workout-pause');state=await api('/api/state');assert(state.data.workout.paused);await action('workout-pause');await action('workout-stop');assert.equal((await api('/api/state')).data.workout,null);
const chat=await api('/api/chat','POST',{text:'Qual é a capital da França?'});assert.match(chat.answer,/fora desses temas/);const chat2=await api('/api/chat','POST',{text:'Quantos copos de água registrei?'});assert.match(chat2.answer,/10 copos/);await action('chat-clear');
const exported=await api('/api/export');assert.equal(exported.profile.name,p.name);assert(!JSON.stringify(exported).includes('password'));
await api('/api/state','POST',{action:'settings',id:crypto.randomUUID(),value:{theme:'dark'}},401,{Origin:'https://evil.example'});
await api('/api/progress','GET',undefined,401,{'oai-authenticated-user-id':'different-user'});
const spoof=await api('/api/progress','GET',undefined,200,{'x-report-account':'someoneelse@example.com'});assert.equal(spoof.events.find(e=>e.kind==='water').amount,10);
const owner=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(platform+':'+email)))).map(n=>n.toString(16).padStart(2,'0')).join('');
localData(owner,data=>{data.gems=150});
const buys=await Promise.all(['blue','purple'].map(value=>fetch(base+'/api/state',{method:'POST',headers:{'Content-Type':'application/json','oai-authenticated-user-id':platform,Cookie:cookie},body:JSON.stringify({action:'buy',value,id:crypto.randomUUID()})}).then(async r=>({status:r.status,data:await r.json(),value}))));assert.deepEqual(buys.map(r=>r.status).sort(),[200,400]);const winner=buys.find(r=>r.status===200).value;state=await api('/api/state');assert.equal(state.data.gems,50);assert(state.data.owned.includes(winner));await action('buy',winner);assert.equal((await api('/api/state')).data.gems,50);await action('equip','apple');
await action('workout-start',{body:'Peito',reps:12,sets:1,rounds:1,duration:30,selected:[0]});localData(owner,data=>{data.workout.deadline=Date.now()-1000});await action('workout-next');h=await api('/api/progress');assert.equal(h.events.find(e=>e.kind==='workout').amount,1);
await action('claim',{mission:'d-workout',day:initial.day});state=await api('/api/state');assert.equal(state.data.gems,60);
localData(owner,(data,db)=>{const real=new Date().toLocaleDateString('sv-SE',{timeZone:'America/Sao_Paulo'});const prev=new Date(Date.parse(real+'T12:00:00Z')-86400000).toISOString().slice(0,10);const jan=real.slice(0,4)+'-01-01';db.prepare('UPDATE report_clocks SET started=?,year=? WHERE owner=?').run(prev,Number(real.slice(0,4)),owner);db.prepare('UPDATE report_events SET id=replace(id,day,?),day=? WHERE owner=?').run(jan,jan,owner);db.prepare('UPDATE meal_days SET id=replace(id,day,?),day=? WHERE owner=?').run(jan,jan,owner);data.created=jan;data.journeyStart=jan;data.goals=data.goals.map(g=>({...g,start:jan,end:jan}));data.claimed=data.claimed.map(key=>key.slice(0,key.lastIndexOf(':')+1)+jan)});h=await api('/api/progress');assert.equal(h.day,initial.day);const migrated=await api('/api/state');assert.equal(migrated.data.gems,60);const before=JSON.stringify(h.events);assert.equal(JSON.stringify((await api('/api/progress')).events),before);assert(h.events.some(e=>e.kind==='sleep'&&e.amount===480));assert(migrated.data.claimed.every(key=>!key.endsWith(initial.day)));assert(!h.events.some(e=>e.day===h.day&&e.kind==='water'));assert((await api('/api/meal-plan')).registered.every(n=>!n));await action('claim',{mission:'d-water',day:h.day},undefined,400);
const savedCookie=cookie;await api('/api/account','DELETE');await api('/api/state','GET',undefined,401);await api('/api/account','POST',{mode:'login',email,password:'wrongpass'},401);await api('/api/account','POST',{mode:'login',email,password});assert.equal((await api('/api/state')).data.gems,60);
await api('/api/account','POST',{mode:'recover',email,password:'ChangedPassword123'});await api('/api/state','GET',undefined,401,{Cookie:savedCookie});await api('/api/account','DELETE');await api('/api/account','POST',{mode:'login',email,password},401);await api('/api/account','POST',{mode:'login',email,password:'ChangedPassword123'});
await api('/api/feedback','POST',{text:'The routine works in this local test.'});await api('/api/state','DELETE',{confirmation:'NO'},400);await api('/api/state','DELETE',{confirmation:'EXCLUIR'});await api('/api/state','GET',undefined,401);
console.log(`PASS: ${checks} local API checks covering authentication, migration boundaries, isolation, required profile, daily caps, idempotent goals, claims, sleep, workout gates, chat scope, recovery, export and deletion`);
