'use client';
import OfflineApp from '../offline-app';
export default OfflineApp;
