'use client';
import {useEffect,useState} from 'react';
import {AppProvider} from './state';import {Screens} from './screens';import {Logo} from './ui';
import {createLocalStore} from '../lib/local-store';import {setLocalTransport,setAppDay} from '../lib/progress';import type {AppState} from '../lib/domain';
export default function OfflineApp(){
 const [initial,setInitial]=useState<{data:AppState;day:string}|null>(null),[started,setStarted]=useState(false),[error,setError]=useState('');
 const boot=()=>{try{const store=createLocalStore(localStorage);setLocalTransport(store.request);const state=store.initial();setAppDay(state.day);setInitial(state);setStarted(!!state.data.profile);setError('')}catch(e){setError((e as Error).message)}};
 useEffect(()=>{boot();window.addEventListener('nutrivida-account-deleted',boot);return()=>{window.removeEventListener('nutrivida-account-deleted',boot);setLocalTransport(null)}},[]);
 if(error)return <main className="auth"><Logo/><p role="alert" className="formError">{error}</p><button className="secondary" onClick={boot}>Tentar novamente</button></main>;
 if(!initial)return <main className="auth"><Logo/><p role="status">Carregando…</p></main>;
 if(!started)return <main className="auth offlineWelcome"><Logo/><p className="tagline">Hábitos hoje, bem-estar sempre.</p><div className="authTitle"><h1>Seu próximo hábito começa aqui.</h1><p>Organize água, refeições, sono, treinos e metas no seu ritmo.</p></div><button className="primary" onClick={()=>setStarted(true)}>{initial.data.profile?'Continuar minha jornada':'Começar minha jornada'}</button><div className="localNotice"><b>Versão para avaliação do curso</b><p>Funciona offline. Os registros ficam neste aparelho, sem cadastro por e-mail. Você pode exportar ou apagar seus dados no Perfil.</p></div><p className="hint">Ferramenta de organização de hábitos. Não substitui orientação individual de saúde.</p></main>;
 return <AppProvider email="Dados salvos neste aparelho" initial={initial} onLogout={()=>{boot();setStarted(false)}}><Screens/></AppProvider>;
}
