'use client';
import {useEffect,useState} from 'react';
import {Logo} from '../ui';
import {localize} from '../translations';
import {requestJSON} from '../../lib/progress';
export default function VerifyEmail(){
 const [token,setToken]=useState(''),[lang,setLang]=useState('pt'),[ready,setReady]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState(''),[confirmed,setConfirmed]=useState(false);
 useEffect(()=>{setToken(new URLSearchParams(window.location.hash.slice(1)).get('token')||'');window.history.replaceState(null,'','/verify-email');setLang(localStorage.getItem('nutrivida_language')||'pt');setReady(true)},[]);
 const confirm=async()=>{if(busy)return;setBusy(true);setError('');try{await requestJSON('/api/verify-email','POST',{token});setToken('');setConfirmed(true)}catch(e){setError((e as Error).message)}finally{setBusy(false)}};
 return <>{localize(<main className="auth"><Logo/><div className="authTitle"><h1>{confirmed?'E-mail confirmado':'Confirme seu e-mail'}</h1><p>{confirmed?'Sua conta está pronta. Continue para preencher seu cadastro.':'Confirme para criar sua conta e continuar no NutriVida.'}</p></div>{error&&<p className="formError" role="alert">{error}</p>}{confirmed?<a className="primary" href="/">Continuar no NutriVida</a>:<><button className="primary" disabled={!ready||!token||busy} onClick={confirm}>{busy?'Aguarde…':'Confirmar e-mail'}</button>{ready&&!token&&<p role="status">Abra o link enviado ao seu e-mail. Se ele expirou, solicite outro no cadastro.</p>}<a className="link" href="/">Voltar para o login</a></>}</main>,lang)}</>;
}
