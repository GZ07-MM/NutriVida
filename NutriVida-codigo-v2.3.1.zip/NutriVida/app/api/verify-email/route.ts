import {env} from 'cloudflare:workers';
import {cookie,errorResponse,hash,platformUser,sameOrigin} from '../../../db/auth';
import {confirmVerification,VerificationError} from '../../../db/email-verification';
export async function POST(request:Request){try{
 sameOrigin(request);const user=platformUser(request);if(!env.DB)throw new Error('DB');
 const {token}=await request.json() as {token?:string};
 const account=await confirmVerification(env.DB,user,typeof token==='string'?token:'');
 const sessionToken=crypto.randomUUID()+crypto.randomUUID();
 await env.DB.prepare('INSERT INTO app_sessions(token,owner,platform_user,email,expires) VALUES(?,?,?,?,?)').bind(await hash(sessionToken),account.owner,await hash(user),account.email,Date.now()+2592000000).run();
 return Response.json({email:account.email},{headers:{'Set-Cookie':cookie(sessionToken,request),'Cache-Control':'no-store'}});
}catch(e){if(e instanceof VerificationError)return Response.json({error:e.message},{status:e.status,headers:{'Cache-Control':'no-store'}});return errorResponse(e)}}
