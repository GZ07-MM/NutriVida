import {hash,passwordHash} from './auth';

export class VerificationError extends Error {constructor(message:string,public status=400){super(message)}}
export const SITE_ORIGIN='https://nutrivida-app.gaivotavoadora123.chatgpt.site';
type MailConfig={RESEND_API_KEY?:string;EMAIL_FROM?:string};
type Pending={owner:string;platform_user:string;email:string;password:string;salt:string;token:string;expires:number;sent_at:number;ready:number};
export function mailConfigured(config:MailConfig){return !!config.RESEND_API_KEY&&!!config.EMAIL_FROM&&/^[^\r\n]+@[^\r\n]+$/.test(config.EMAIL_FROM)}

export async function requestVerification(db:D1Database,user:string,email:string,password:string,config:MailConfig,send:typeof fetch=fetch){
 if(!mailConfigured(config))throw new VerificationError('O cadastro está temporariamente indisponível. Falta ativar o envio dos e-mails de confirmação.',503);
 const now=Date.now(),owner=await hash(user+':'+email),platform=await hash(user);
 if(await db.prepare('SELECT owner FROM app_accounts WHERE owner=?').bind(owner).first())throw new VerificationError('Essa conta já existe. Use Entrar ou Esqueceu sua senha.',409);
 const existing=await db.prepare('SELECT sent_at FROM email_verifications WHERE owner=?').bind(owner).first<{sent_at:number}>();
 if(existing&&existing.sent_at>now-60000)throw new VerificationError('Aguarde um minuto antes de pedir outro e-mail.',429);
 // Reserve a platform-wide quota atomically, including failed sends and concurrent requests.
 const quota=await db.prepare(`INSERT INTO email_send_limits(platform_user,window_start,count) VALUES(?,?,1)
 ON CONFLICT(platform_user) DO UPDATE SET window_start=CASE WHEN window_start<=? THEN excluded.window_start ELSE window_start END,
 count=CASE WHEN window_start<=? THEN 1 ELSE count+1 END WHERE window_start<=? OR count<5 RETURNING count`).bind(platform,now,now-3600000,now-3600000,now-3600000).first();
 if(!quota)throw new VerificationError('Você já solicitou vários e-mails. Tente novamente em uma hora.',429);
 const raw=crypto.randomUUID()+crypto.randomUUID(),token=await hash(raw),salt=crypto.randomUUID();
 const saved=await db.prepare(`INSERT INTO email_verifications(owner,platform_user,email,password,salt,token,expires,sent_at,ready) VALUES(?,?,?,?,?,?,?,?,0)
 ON CONFLICT(owner) DO UPDATE SET password=excluded.password,salt=excluded.salt,token=excluded.token,expires=excluded.expires,sent_at=excluded.sent_at,ready=0 WHERE sent_at<=? RETURNING owner`).bind(owner,platform,email,await passwordHash(password,salt),salt,token,now+1800000,now,now-60000).first();
 if(!saved)throw new VerificationError('Aguarde um minuto antes de pedir outro e-mail.',429);
 const link=SITE_ORIGIN+'/verify-email#token='+raw;
 try{
  const response=await send('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+config.RESEND_API_KEY,'Content-Type':'application/json','Idempotency-Key':'signup-'+token},body:JSON.stringify({from:config.EMAIL_FROM,to:[email],subject:'Confirme seu e-mail no NutriVida',text:`Confirme seu e-mail para criar sua conta no NutriVida:\n\n${link}\n\nO link expira em 30 minutos e só pode ser usado uma vez. Abra com o mesmo acesso do ChatGPT usado no cadastro. Se não foi você, ignore esta mensagem.`}),signal:AbortSignal.timeout(10000)});
  if(!response.ok)throw new Error('Delivery rejected');
  const result=await response.json() as {id?:string};if(!result.id)throw new Error('Delivery unavailable');
  await db.prepare('UPDATE email_verifications SET ready=1 WHERE owner=? AND token=?').bind(owner,token).run();
 }catch{
  await db.prepare('DELETE FROM email_verifications WHERE owner=? AND token=?').bind(owner,token).run();
  throw new VerificationError('Não foi possível enviar a confirmação. Confira o endereço e tente novamente.',503);
 }
 return {pending:true,email};
}

export async function confirmVerification(db:D1Database,user:string,raw:string){
 if(!/^[a-f0-9-]{72}$/.test(raw))throw new VerificationError('Este link é inválido ou expirou. Solicite outra confirmação.',410);
 const token=await hash(raw),platform=await hash(user),now=Date.now();
 const pending=await db.prepare('SELECT * FROM email_verifications WHERE token=? AND platform_user=? AND expires>? AND ready=1').bind(token,platform,now).first<Pending>();
 if(!pending)throw new VerificationError('Este link é inválido ou expirou. Solicite outra confirmação pelo mesmo acesso usado no cadastro.',410);
 // The account and token consumption form one transaction. Only the first confirmation succeeds.
 const result=await db.batch([
  db.prepare(`INSERT OR IGNORE INTO app_accounts(owner,platform_user,email,password,salt,attempts,locked_until,created)
 SELECT owner,platform_user,email,password,salt,0,0,? FROM email_verifications WHERE token=? AND platform_user=? AND expires>? AND ready=1`).bind(new Date(now).toISOString(),token,platform,now),
  db.prepare('DELETE FROM email_verifications WHERE token=? AND platform_user=?').bind(token,platform)
 ]);
 if(!result[0].meta.changes)throw new VerificationError('Este link já foi utilizado. Entre na sua conta.',410);
 return {owner:pending.owner,email:pending.email};
}
