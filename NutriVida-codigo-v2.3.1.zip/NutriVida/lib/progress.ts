export type ProgressEvent={day:string;kind:string;amount:number};
export type ProgressHistory={day:string;events:ProgressEvent[]};
let clockDay:string|null=null;
export function appDate(){return new Date(appDay()+'T12:00:00')}
export function appDay(){return clockDay||new Date().toLocaleDateString('sv-SE',{timeZone:'America/Sao_Paulo'})}
export function setAppDay(day:string){clockDay=day}
export function progressHeaders(){return {'Content-Type':'application/json'}}
export type LocalTransport=(url:string,method:string,body?:unknown)=>Promise<unknown>;
let localTransport:LocalTransport|null=null;
export function setLocalTransport(transport:LocalTransport|null){localTransport=transport}
export function isLocalMode(){return localTransport!==null}
export async function requestJSON<T>(url:string,method='GET',body?:unknown):Promise<T>{if(localTransport)return await localTransport(url,method,body) as T;const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);try{const r=await fetch(url,{method,headers:progressHeaders(),credentials:'same-origin',signal:controller.signal,body:body===undefined?undefined:JSON.stringify(body),cache:'no-store'});const data=await r.json() as T & {error?:string};if(!r.ok)throw new Error(data.error||'Não foi possível salvar. Tente novamente.');return data as T}catch(e){if(e instanceof DOMException&&e.name==='AbortError')throw new Error('Tempo de resposta excedido. Tente novamente.');if(e instanceof TypeError)throw new Error('Sem conexão. Seu registro ainda não foi salvo. Tente novamente.');throw e}finally{clearTimeout(timer)}}
export async function loadHistory():Promise<ProgressHistory>{const data=await requestJSON<ProgressHistory>('/api/progress');clockDay=data.day;return data}
export async function recordActivity(kind:string,amount=1,id:string=crypto.randomUUID()):Promise<boolean>{try{const data=await requestJSON<{day:string}>('/api/progress','POST',{kind,amount,id});clockDay=data.day;window.dispatchEvent(new Event('nutrivida-progress'));return true}catch(e){window.dispatchEvent(new CustomEvent('nutrivida-save-error',{detail:e instanceof Error?e.message:'Não foi possível salvar. Tente novamente.'}));return false}}
