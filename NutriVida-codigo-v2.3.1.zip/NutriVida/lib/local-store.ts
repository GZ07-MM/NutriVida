import {initialState,normalizeTheme,validTime,type AppState,type Event} from './domain';
import {applyStateAction} from './state-actions';
import {guided} from './guided-chat';
import {allergens,defaultPreferences,type FoodPreferences} from './food-options';

export const LOCAL_KEY='nutrivida-local-v1';
type Entry=Event&{id:string};
type Snapshot={version:1;data:AppState;events:Entry[];times:string[];days:Record<string,string[]>;preferences:FoodPreferences;preferenceSaved:boolean;feedback:{id:string;text:string}[]};
type StoragePort=Pick<Storage,'getItem'|'setItem'|'removeItem'>;
export function createLocalStore(storage:StoragePort,clock=()=>new Date()){
 const day=()=>clock().toLocaleDateString('sv-SE',{timeZone:'America/Sao_Paulo'});
 const fresh=():Snapshot=>({version:1,data:initialState(day()),events:[],times:[],days:{},preferences:structuredClone(defaultPreferences),preferenceSaved:false,feedback:[]});
 const read=():Snapshot=>{const raw=storage.getItem(LOCAL_KEY);if(!raw)return fresh();try{const s=JSON.parse(raw);if(s.version!==1||!s.data||!Array.isArray(s.events))throw new Error();s.data.settings.theme=normalizeTheme(s.data.settings.theme);return s}catch{throw new Error('Não foi possível ler os dados salvos. Exporte uma cópia antes de redefinir o aplicativo.')}};
 const history=(s:Snapshot)=>{const totals=new Map<string,Event>();for(const e of s.events){const key=e.day+':'+e.kind;const row=totals.get(key)||{day:e.day,kind:e.kind,amount:0};row.amount+=e.amount;totals.set(key,row)}return [...totals.values()].sort((a,b)=>a.day.localeCompare(b.day))};
 const add=(s:Snapshot,kind:string,amount:number,id:string)=>{const key=kind+':'+id;if(s.events.some(e=>e.id===key))return false;s.events.push({day:day(),kind,amount,id:key});return true};
 const meal=(s:Snapshot)=>{const times=s.days[day()]||s.times;return {day:day(),times,plannedTimes:s.times,locked:!!s.days[day()],registered:times.map((_,i)=>s.events.some(e=>e.id==='meal:planned-'+day()+'-'+i))}};
 const execute=(url:string,method:string,body?:unknown)=>{
  const b=body as any,s=read(),d=day();let result:unknown;
  switch(url){
   case '/api/state':
    if(method==='DELETE'){if(b?.confirmation!=='EXCLUIR')throw new Error('Digite EXCLUIR para confirmar.');storage.removeItem(LOCAL_KEY);return {ok:true}}
    if(method==='POST'){const r=applyStateAction(s.data,d,b,history(s),clock().getTime());s.data=r.next;if(r.event)add(s,r.event.kind,r.event.amount,r.event.id)}
    result={data:s.data,day:d};break;
   case '/api/progress':
    if(method==='POST'){const limits:Record<string,number>={presence:1,water:1,consumed:10000,spent:10000};if(!limits[b?.kind]||!Number.isFinite(b.amount)||b.amount<=0||b.amount>limits[b.kind]||(['water','presence'].includes(b.kind)&&b.amount!==1)||typeof b.id!=='string'||!b.id||b.id.length>120)throw new Error('Registro inválido.');const n=history(s).filter(e=>e.day===d&&e.kind===b.kind).reduce((n,e)=>n+e.amount,0);const inserted=n<(b.kind==='water'?10:100000)&&add(s,b.kind,b.amount,b.kind==='presence'?'presence'+d:b.id);result={day:d,total:n+(inserted?b.amount:0),inserted}}else result={day:d,events:history(s)};break;
   case '/api/meal-plan':
    if(method==='PUT'){if(!Array.isArray(b?.times)||b.times.length!==4||!b.times.every(validTime))throw new Error('Preencha os horários das quatro refeições.');s.times=[...b.times]}
    if(method==='POST'){const plan=meal(s);if(!Number.isInteger(b?.slot)||b.slot<0||b.slot>=plan.times.length)throw new Error('Escolha uma refeição prevista para hoje.');s.days[d]=[...plan.times];add(s,'meal',1,'planned-'+d+'-'+b.slot)}result=meal(s);break;
   case '/api/food-preferences':
    if(method==='PUT'){if(!Array.isArray(b?.avoid)||!b.avoid.every((a:string)=>allergens.some(([id])=>id===a))||!Array.isArray(b.excluded)||b.excluded.length>30||!b.excluded.every((v:unknown)=>typeof v==='string'&&v.trim()&&v.length<=60)||!['any','vegetarian','vegan'].includes(b.diet)||!['any','low'].includes(b.budget??'any')||![0,15,30,60].includes(b.maxMinutes??0)||!Array.isArray(b.pantry??[])||(b.pantry??[]).length>50||!(b.pantry??[]).every((v:unknown)=>typeof v==='string'&&v.trim()&&v.length<=60)||typeof (b.pantryOnly??false)!=='boolean')throw new Error('Revise suas preferências.');s.preferences={...defaultPreferences,...b};s.preferenceSaved=true}result={preferences:s.preferences,saved:s.preferenceSaved};break;
   case '/api/chat':
    if(method==='POST'){if(typeof b?.text!=='string'||!b.text.trim()||b.text.length>1500)throw new Error('Escreva uma mensagem de até 1.500 caracteres.');const answer=guided(b.text,s.data.profile?.lang||'pt',d,history(s));s.data.chat=[...s.data.chat,{role:'user' as const,text:b.text.trim()},{role:'assistant' as const,text:answer}].slice(-60);result={answer,mode:'guided'}}else result={generative:false};break;
   case '/api/feedback':
    if(typeof b?.text!=='string'||b.text.trim().length<10||b.text.length>2000)throw new Error('Descreva o problema em 10 a 2.000 caracteres.');const id=crypto.randomUUID();s.feedback.push({id,text:b.text.trim()});result={id};break;
   case '/api/account':
    if(method==='POST')throw new Error('Esta versão salva os dados neste aparelho e não usa senha.');return {email:null};
   case '/api/export':return {...s,exported:clock().toISOString(),day:d,events:history(s)};
   default:throw new Error('Recurso indisponível nesta versão.');
  }
  if(method!=='GET'){try{storage.setItem(LOCAL_KEY,JSON.stringify(s))}catch{throw new Error('Não foi possível salvar no aparelho. Verifique o espaço disponível e tente novamente.')}}
  return structuredClone(result);
 };
 // Queue writes so rapid taps never overwrite another successful registration.
 let queue:Promise<unknown>=Promise.resolve();
 const request=(url:string,method='GET',body?:unknown):Promise<any>=>{const result=queue.then(()=>execute(url,method,body));queue=result.catch(()=>{});return result};
 return {request,initial:()=>({data:read().data,day:day()})};
}
