# Confirmação de e-mail

Novos cadastros só criam uma conta após confirmação por link recebido no endereço informado. Validar o formato ou o domínio não comprova que a caixa de entrada existe.

Configure no ambiente hospedado, sem colocar chaves no código:

- `RESEND_API_KEY`: chave de envio do Resend.
- `EMAIL_FROM`: remetente em um domínio verificado, por exemplo `NutriVida <conta@seu-dominio.com>`.

Enquanto o envio não estiver configurado, novos cadastros ficam indisponíveis. Não há modo que crie contas automaticamente ou apresente uma confirmação fictícia. Contas anteriores continuam podendo entrar; não são tratadas como e-mails já confirmados.

O domínio de envio precisa estar verificado no Resend. A chave deve permitir envio nesse domínio. Use a integração Resend para configurar o remetente e forneça a chave somente por um mecanismo de segredo, nunca pelo chat ou formulário público.

O link usa o endereço hospedado de NutriVida, expira em 30 minutos e tem uso único. O usuário precisa abrir com o mesmo acesso do ChatGPT usado para solicitar o cadastro, porque o app é privado. Se o endereço do site mudar, atualize `SITE_ORIGIN` em `db/email-verification.ts` antes de enviar novos links.

O banco guarda apenas hashes de senha e de token. Há um intervalo mínimo de um minuto para reenvio e um limite de cinco pedidos por hora por identidade. A conta só é criada quando o usuário confirma explicitamente o link; pré-visualizadores de e-mail não consomem a confirmação.

Validação automatizada: `node tests/email-verification.mjs`. O teste usa entrega simulada, sem enviar mensagens reais. Depois de configurar o remetente, testar entrega e confirmação com uma caixa de entrada real para concluir a ativação.
