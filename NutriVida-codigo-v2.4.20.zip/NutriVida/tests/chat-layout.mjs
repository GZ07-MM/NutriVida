import assert from 'node:assert/strict';
import {trackChatLayout} from '../lib/chat-layout.ts';

const win=new EventTarget(),values=new Map();let navHeight=79,composerHeight=62,bottom=12,observed=[],disconnected=false;
Object.assign(win,{document:{documentElement:{style:{setProperty:(key,value)=>values.set(key,value),removeProperty:key=>values.delete(key)}}},getComputedStyle:()=>({bottom:bottom+'px'}),ResizeObserver:class{constructor(callback){this.callback=callback}observe(target){observed.push(target)}disconnect(){disconnected=true}}});
const nav={getBoundingClientRect:()=>({height:navHeight})},composer={getBoundingClientRect:()=>({height:composerHeight})};
const layout=trackChatLayout(win,composer,nav);assert.deepEqual(observed,[nav,composer]);
for(const height of [79,110,160])for(const fieldHeight of [62,90,146]){
 navHeight=height;composerHeight=fieldHeight;layout.measure();
 const clearance=parseFloat(values.get('--chat-nav-clearance')),field=parseFloat(values.get('--chat-composer-height'));
 assert.equal(clearance,height+bottom+15);assert.equal(field,fieldHeight);
 for(const viewport of [600,800,1200]){
  const navTop=viewport-bottom-height,composerBottom=viewport-clearance;
  assert.equal(navTop-composerBottom,15);assert(viewport-(clearance+field+24)<composerBottom-field);
 }
}
navHeight=0;layout.measure();assert.equal(values.get('--chat-nav-clearance'),'187px');
navHeight=79;bottom=24;win.dispatchEvent(new Event('resize'));assert.equal(values.get('--chat-nav-clearance'),'118px');
layout.dispose();assert(disconnected);assert.equal(values.size,0);win.dispatchEvent(new Event('resize'));assert.equal(values.size,0);
console.log('PASS: navigation/composer clearance across viewport sizes, large text, expanding drafts, hidden keyboard navigation and cleanup');
