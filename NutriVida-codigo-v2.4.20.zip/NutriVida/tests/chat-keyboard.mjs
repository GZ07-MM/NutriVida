import assert from 'node:assert/strict';
import {followChatKeyboard} from '../lib/chat-keyboard.ts';

function device(withViewport=true){
 const input=new EventTarget(),win=new EventTarget(),viewport=new EventTarget(),styles=new Map(),classes=new Set(),frames=new Map();let id=0,reveals=0;
 Object.assign(viewport,{height:800,width:390,offsetTop:0,scale:1});
 Object.assign(win,{innerHeight:800,innerWidth:390,visualViewport:withViewport?viewport:null,document:{activeElement:null,documentElement:{style:{setProperty:(key,value)=>styles.set(key,value),removeProperty:key=>styles.delete(key)},classList:{add:key=>classes.add(key),toggle:(key,on)=>on?classes.add(key):classes.delete(key),remove:key=>classes.delete(key)}}},requestAnimationFrame:callback=>{frames.set(++id,callback);return id},cancelAnimationFrame:key=>frames.delete(key)});
 const flush=()=>{const tasks=[...frames.values()];frames.clear();tasks.forEach(callback=>callback())};
 const emit=(target,type)=>{target.dispatchEvent(new Event(type));flush()};
 const dispose=followChatKeyboard(win,input,()=>reveals++);
 return {win,input,viewport,styles,classes,frames,emit,flush,dispose,reveals:()=>reveals,focus(){win.document.activeElement=input;emit(input,'focus')}};
}
const overlay=device();assert(overlay.classes.has('chatScreen'));assert.equal(overlay.styles.get('--chat-viewport-height'),'800px');overlay.focus();assert(!overlay.classes.has('chatKeyboard'));
overlay.viewport.height=520;overlay.emit(overlay.viewport,'resize');assert(overlay.classes.has('chatKeyboard'));assert.equal(overlay.styles.get('--chat-keyboard-inset'),'280px');assert.equal(overlay.reveals(),1);
overlay.viewport.height=500;overlay.emit(overlay.viewport,'resize');assert.equal(overlay.styles.get('--chat-keyboard-inset'),'300px');
const beforeScroll=overlay.reveals();overlay.viewport.offsetTop=20;overlay.emit(overlay.viewport,'scroll');assert.equal(overlay.styles.get('--chat-keyboard-inset'),'280px');assert.equal(overlay.reveals(),beforeScroll);
overlay.viewport.offsetTop=0;overlay.viewport.height=800;overlay.emit(overlay.viewport,'resize');assert(!overlay.classes.has('chatKeyboard'));assert.equal(overlay.styles.get('--chat-keyboard-inset'),'0px');

const resized=device();resized.focus();resized.win.innerHeight=500;resized.viewport.height=500;resized.emit(resized.win,'resize');assert(resized.classes.has('chatKeyboard'));assert.equal(resized.styles.get('--chat-keyboard-inset'),'0px');
resized.win.innerHeight=800;resized.viewport.height=800;resized.emit(resized.viewport,'resize');assert(!resized.classes.has('chatKeyboard'));
resized.viewport.scale=2;resized.viewport.height=400;resized.viewport.width=195;resized.emit(resized.viewport,'resize');assert(!resized.classes.has('chatKeyboard'));
resized.viewport.scale=1;resized.viewport.height=800;resized.viewport.width=390;resized.emit(resized.viewport,'resize');
resized.win.innerHeight=390;resized.viewport.height=390;resized.viewport.width=800;resized.win.innerWidth=800;resized.emit(resized.win,'orientationchange');assert(!resized.classes.has('chatKeyboard'));

const fallback=device(false);fallback.focus();fallback.win.innerHeight=480;fallback.emit(fallback.win,'resize');assert(fallback.classes.has('chatKeyboard'));
fallback.win.innerHeight=800;fallback.emit(fallback.win,'resize');assert(!fallback.classes.has('chatKeyboard'));

// The actual controller drives a continuous composer position through every
// intermediate keyboard frame, including the former 120px mode-switch jump.
for(const nav of [106,137,187])for(const adjustResize of [false,true]){
 const animated=device();animated.focus();
 const position=()=>Number.parseFloat(animated.styles.get('--chat-viewport-height'))-Math.max(12,nav-Number.parseFloat(animated.styles.get('--chat-keyboard-height')));
 let previous=position();
 for(const reduction of [20,60,90,119,120,121,150,240,320]){
  animated.viewport.height=800-reduction;if(adjustResize)animated.win.innerHeight=800-reduction;
  animated.emit(animated.viewport,'resize');const current=position();
  assert(current<=previous,'Opening the keyboard must never send the composer downward');
  assert(current<=animated.viewport.height-12,'Composer must stay above the keyboard');previous=current;
 }
 animated.win.document.activeElement=null;animated.emit(animated.input,'blur');
 for(const reduction of [240,150,121,120,119,90,60,20,0]){
  animated.viewport.height=800-reduction;if(adjustResize)animated.win.innerHeight=800-reduction;
  animated.emit(animated.viewport,'resize');const current=position();
  assert(current>=previous,'Closing the keyboard must never send the composer upward');previous=current;
 }
 assert.equal(position(),800-nav);assert(!animated.classes.has('chatKeyboard'));animated.dispose();
}
const jitter=device();jitter.focus();jitter.viewport.height=679;jitter.emit(jitter.viewport,'resize');
for(const height of [680,681,678,682]){jitter.viewport.height=height;jitter.emit(jitter.viewport,'resize');assert(jitter.classes.has('chatKeyboard'),'Intermediate resize events must not toggle navigation back and forth')}
// Duplicate window and visual viewport events share one frame and one scroll.
const beforeDuplicate=jitter.reveals();jitter.viewport.height=500;jitter.win.dispatchEvent(new Event('resize'));jitter.viewport.dispatchEvent(new Event('resize'));assert.equal(jitter.frames.size,1);jitter.flush();assert.equal(jitter.reveals(),beforeDuplicate+1);
jitter.emit(jitter.viewport,'resize');assert.equal(jitter.reveals(),beforeDuplicate+1);
for(const test of [overlay,resized,fallback,jitter]){test.win.dispatchEvent(new Event('resize'));assert(test.frames.size>0);test.dispose();assert.equal(test.frames.size,0);assert(!test.classes.has('chatKeyboard'));assert(!test.styles.has('--chat-keyboard-inset'));assert(!test.styles.has('--chat-keyboard-height'));assert(!test.classes.has('chatScreen'));assert(!test.styles.has('--chat-viewport-height'));assert(!test.styles.has('--chat-viewport-top'));test.emit(test.win,'resize');assert.equal(test.frames.size,0)}
console.log('PASS: continuous keyboard opening/closing, navigation hysteresis, coalesced resize events, overlay, resized WebView, panning, zoom, orientation, fallback and cleanup');
