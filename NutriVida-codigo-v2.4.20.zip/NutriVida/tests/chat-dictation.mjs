import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createChatDictation} from '../lib/chat-dictation.ts';

class Recognizer {
 static instances=[];
 constructor(){Recognizer.instances.push(this)}
 start(){this.started=true}
 stop(){this.stopped=true}
 abort(){this.aborted=true}
 result(...segments){this.onresult?.({results:segments.map(transcript=>[{transcript}])})}
}
const drafts=[],states=[],errors=[];
const voice=createChatDictation({webkitSpeechRecognition:Recognizer},{draft:text=>drafts.push(text),state:state=>states.push(state),error:text=>errors.push(text)});
voice.start('Quero saber sobre');
let speech=Recognizer.instances.at(-1);
assert.equal(speech.lang,'pt-BR');assert(speech.started);assert(speech.continuous);assert(speech.interimResults);
speech.result('ali');speech.result('alimentação');speech.result('alimentação','e água');speech.result('alimentação','e água');
assert.deepEqual(drafts,['Quero saber sobre ali','Quero saber sobre alimentação','Quero saber sobre alimentação e água','Quero saber sobre alimentação e água']);
voice.start('another');assert.equal(Recognizer.instances.length,1,'Repeated start never requests another microphone');
voice.stop();assert(speech.stopped);assert.equal(states.at(-1),'stopping');
speech.result('alimentação','e hidratação');assert.equal(drafts.at(-1),'Quero saber sobre alimentação e hidratação');
speech.onend();assert.equal(states.at(-1),'idle');assert.equal(speech.onresult,null);
voice.start(drafts.at(-1),'es');speech=Recognizer.instances.at(-1);assert.equal(speech.lang,'es-ES');
speech.result('por favor');assert.equal(drafts.at(-1),'Quero saber sobre alimentação e hidratação por favor');
const late=speech.onresult,lateEnd=speech.onend;
voice.cancel();assert(speech.aborted);const count=drafts.length;late({results:[[{transcript:'late overwrite'}]]});assert.equal(drafts.length,count,'Cancel ignores late results after editing or sending');
voice.start('','en');const next=Recognizer.instances.at(-1);lateEnd();assert.equal(states.at(-1),'listening','Old end cannot terminate a new session');assert.equal(next.lang,'en-US');
next.onerror({error:'not-allowed'});assert.equal(states.at(-1),'idle');assert.match(errors.at(-1),/Permita/);
const deniedCount=Recognizer.instances.length;assert.equal(Recognizer.instances.length,deniedCount,'No auto restart after permission denial');
voice.start('');speech=Recognizer.instances.at(-1);speech.onerror({error:'network'});assert.match(errors.at(-1),/conexão/);
voice.start('');speech=Recognizer.instances.at(-1);speech.onerror({error:'no-speech'});assert.match(errors.at(-1),/Nenhuma fala/);
voice.start('');speech=Recognizer.instances.at(-1);const errorCount=errors.length;speech.onerror({error:'aborted'});assert.equal(errors.length,errorCount);
voice.start('A'.repeat(1498));speech=Recognizer.instances.at(-1);speech.result('algo longo');assert.equal(drafts.at(-1).length,1500);assert(speech.aborted);assert.equal(states.at(-1),'idle');
const fullCount=Recognizer.instances.length;voice.start('A'.repeat(1500));assert.equal(Recognizer.instances.length,fullCount);assert.match(errors.at(-1),/limite/);
voice.start('Texto com espaço ');speech=Recognizer.instances.at(-1);speech.result('fala');assert.equal(drafts.at(-1),'Texto com espaço fala');
const afterDispose=speech.onresult,stateCount=states.length;voice.dispose();assert(speech.aborted);afterDispose({results:[[{transcript:'never'}]]});assert.equal(states.length,stateCount,'Unmount does not update React state');
const disposedCount=Recognizer.instances.length;voice.start('');assert.equal(Recognizer.instances.length,disposedCount);

const unsupported=[];createChatDictation({},{draft:()=>assert.fail(),state:()=>assert.fail(),error:text=>unsupported.push(text)}).start('');assert.match(unsupported[0],/microfone do teclado/);
class Broken extends Recognizer{start(){throw Error('broken')}}
const brokenStates=[];createChatDictation({SpeechRecognition:Broken},{draft:()=>assert.fail(),state:s=>brokenStates.push(s),error:()=>{}}).start('');assert.deepEqual(brokenStates,['listening','idle']);assert(Recognizer.instances.at(-1).aborted);

// A recognizer that fails to emit end cannot lock the composer indefinitely.
const originalSet=globalThis.setTimeout,originalClear=globalThis.clearTimeout;let timeout,cleared=false;
globalThis.setTimeout=callback=>{timeout=callback;return 1};globalThis.clearTimeout=()=>{cleared=true};
try{
 const stalledStates=[],stalled=createChatDictation({SpeechRecognition:Recognizer},{draft:()=>{},state:s=>stalledStates.push(s),error:()=>{}});
 stalled.start('');const engine=Recognizer.instances.at(-1);stalled.stop();assert.equal(stalledStates.at(-1),'stopping');timeout();assert.equal(stalledStates.at(-1),'idle');assert(engine.aborted);assert(cleared);stalled.dispose();
}finally{globalThis.setTimeout=originalSet;globalThis.clearTimeout=originalClear}

const screen=readFileSync(new URL('../app/ai-screen.tsx',import.meta.url),'utf8');
assert(screen.includes('type="button" className="dictationButton"'),'Microphone never submits the form');
assert(screen.includes("disabled={sending||dictationState!=='idle'||!input.trim()}"),'Send waits for dictation to finish');
assert(screen.includes('dictation.current?.cancel();setInput(e.target.value)'),'Manual editing cancels speech updates');
assert(screen.includes("document.visibilityState==='hidden'"));assert(screen.includes('voice.dispose()'));
console.log('PASS: dictation draft preservation, partial/final revisions, stop, stale events, editing, cleanup, character limit, languages, errors, unsupported browsers and stalled recognizers');
