export type ChatMessage={role:'user'|'assistant';text:string};
export type PendingChat={text:string;baseline:string;answer?:string};
export function chatCommitted(messages:ChatMessage[],pending:PendingChat){
 const last=messages.slice(-2);
 return pending.answer!==undefined&&last[0]?.role==='user'&&last[0].text===pending.text.trim()&&last[1]?.role==='assistant'&&last[1].text===pending.answer&&(JSON.stringify(messages)!==pending.baseline||messages.length===60);
}
export function visibleChat(messages:ChatMessage[],pending:PendingChat|null):ChatMessage[]{
 if(!pending||chatCommitted(messages,pending))return messages;
 return [...messages,{role:'user',text:pending.text.trim()},...(pending.answer!==undefined?[{role:'assistant' as const,text:pending.answer}]:[])];
}
