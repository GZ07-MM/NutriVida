type AndroidBridge={setTheme:(dark:boolean)=>void;saveFile:(name:string,mime:string,base64:string)=>void;openAlarm:(hours:number,minutes:number)=>void};
declare global{interface Window{NutriVidaAndroid?:AndroidBridge}}
export function saveText(name:string,text:string,mime='application/json'){
 if(window.NutriVidaAndroid){const bytes=new TextEncoder().encode(text);let binary='';for(const byte of bytes)binary+=String.fromCharCode(byte);window.NutriVidaAndroid.saveFile(name,mime,btoa(binary));return}
 const url=URL.createObjectURL(new Blob([text],{type:mime})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
