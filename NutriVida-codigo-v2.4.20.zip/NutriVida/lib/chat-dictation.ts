// Native browser dictation writes a draft; sending remains the user's action.
type SpeechResult = {length:number; [index:number]:{transcript:string}};
type SpeechEvent = {results:{length:number; [index:number]:SpeechResult}};
export type DictationState = 'idle'|'listening'|'stopping';
export interface SpeechRecognizer {
 lang:string; continuous:boolean; interimResults:boolean; maxAlternatives:number;
 onresult:((event:SpeechEvent)=>void)|null; onerror:((event:{error:string})=>void)|null;
 onend:(()=>void)|null; start():void; stop():void; abort():void;
}
type SpeechConstructor = new()=>SpeechRecognizer;
export type SpeechHost = {SpeechRecognition?:SpeechConstructor; webkitSpeechRecognition?:SpeechConstructor};
const errors:Record<string,string> = {
 'not-allowed':'Permita o acesso ao microfone nas configurações do navegador para ditar.',
 'service-not-allowed':'O reconhecimento de voz não está disponível neste navegador. Use o microfone do teclado.',
 'audio-capture':'Não foi possível acessar o microfone. Confira se ele está disponível.',
 network:'Não foi possível reconhecer a fala. Confira sua conexão e tente novamente.',
 'no-speech':'Nenhuma fala foi reconhecida. Toque no microfone para tentar novamente.',
 'language-not-supported':'O navegador não oferece ditado neste idioma. Use o microfone do teclado.'
};
export function createChatDictation(host:SpeechHost,callbacks:{draft:(text:string)=>void; state:(state:DictationState)=>void; error:(text:string)=>void}){
 let active:SpeechRecognizer|null=null, timer:ReturnType<typeof setTimeout>|undefined;
 let state:DictationState='idle',disposed=false;
 const setState=(value:DictationState)=>{state=value;if(!disposed)callbacks.state(value)};
 const detach=(recognition:SpeechRecognizer)=>{recognition.onresult=null;recognition.onerror=null;recognition.onend=null};
 const finish=(recognition:SpeechRecognizer)=>{
  if(active!==recognition)return;
  clearTimeout(timer);timer=undefined;detach(recognition);active=null;setState('idle');
 };
 const cancel=()=>{const recognition=active;if(!recognition)return;finish(recognition);try{recognition.abort()}catch{}};
 const stop=()=>{
  const recognition=active;if(!recognition||state==='stopping')return;
  setState('stopping');
  // Accept the recognizer's final result, but never leave controls locked if it stalls.
  timer=setTimeout(()=>{if(active===recognition)cancel()},2500);
  try{recognition.stop()}catch{cancel()}
 };
 return {
  start(draft:string,language='pt'){
   if(disposed||active)return;
   const Constructor=host.SpeechRecognition||host.webkitSpeechRecognition;
   if(!Constructor){callbacks.error('Este navegador não oferece ditado por voz. Use o microfone do teclado ou abra no Chrome.');return}
   if(draft.length>=1500){callbacks.error('A mensagem atingiu o limite de 1.500 caracteres. Edite o texto antes de ditar.');return}
   let recognition:SpeechRecognizer;
   try{recognition=new Constructor()}catch{callbacks.error('Não foi possível iniciar o ditado neste navegador. Use o microfone do teclado.');return}
   active=recognition;
   recognition.lang=language==='en'?'en-US':language==='es'?'es-ES':'pt-BR';
   recognition.continuous=true;recognition.interimResults=true;recognition.maxAlternatives=1;
   recognition.onresult=event=>{
    if(active!==recognition||disposed)return;
    // Results are cumulative: replace the session's transcript, including revisions.
    const segments:string[]=[];
    for(let index=0;index<event.results.length;index++)segments.push(event.results[index][0]?.transcript.trim()||'');
    const spoken=segments.filter(Boolean).join(' ');
    const text=spoken?draft+(draft&&!/\s$/.test(draft)?' ':'')+spoken:draft;
    callbacks.draft(text.slice(0,1500));
    if(text.length>=1500){callbacks.error('A mensagem atingiu o limite de 1.500 caracteres.');cancel()}
   };
   recognition.onerror=event=>{
    if(active!==recognition||disposed)return;
    const code=event.error;cancel();
    if(code!=='aborted')callbacks.error(errors[code]||'Não foi possível reconhecer a fala. Tente novamente ou digite sua mensagem.');
   };
   recognition.onend=()=>finish(recognition);
   setState('listening');
   try{recognition.start()}catch{cancel();callbacks.error('Não foi possível iniciar o ditado. Confira o acesso ao microfone e tente novamente.')}
  },stop,cancel,
  dispose(){disposed=true;cancel()}
 };
}
