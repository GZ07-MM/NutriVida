// Reserve real navigation/composer sizes instead of relying on a fixed phone size.
export function trackChatLayout(win:Window,composer:HTMLElement,nav:HTMLElement){
 const root=win.document.documentElement;
 const measure=()=>{
  const navHeight=nav.getBoundingClientRect().height;
  if(navHeight>0){const bottom=Number.parseFloat(win.getComputedStyle(nav).bottom)||0;root.style.setProperty('--chat-nav-clearance',`${navHeight+bottom+15}px`)}
  root.style.setProperty('--chat-composer-height',`${composer.getBoundingClientRect().height}px`);
 };
 const Observer=(win as Window&{ResizeObserver?:typeof ResizeObserver}).ResizeObserver;
 const observer=Observer?new Observer(measure):null;
 observer?.observe(nav);observer?.observe(composer);win.addEventListener('resize',measure);measure();
 return {measure,dispose(){observer?.disconnect();win.removeEventListener('resize',measure);root.style.removeProperty('--chat-nav-clearance');root.style.removeProperty('--chat-composer-height')}};
}
