// Track both overlay keyboards and WebViews that resize the layout viewport.
export function followChatKeyboard(win:Window,input:HTMLInputElement|HTMLTextAreaElement,reveal:()=>void){
 const viewport=win.visualViewport,root=win.document.documentElement;
 let baseline=viewport?.height||win.innerHeight,width=viewport?.width||win.innerWidth,opened=false,tracking=false,frame=0,lastHeight=0,lastKeyboardHeight=0;
 const update=()=>{
  frame=0;
  const height=viewport?.height||win.innerHeight,currentWidth=viewport?.width||win.innerWidth,scale=viewport?.scale||1;
  const focused=win.document.activeElement===input;
  if(focused)tracking=true;
  if(Math.abs(currentWidth-width)>80&&scale===1){baseline=Math.max(height,win.innerHeight);width=currentWidth}
  if(!focused&&!opened&&!tracking)baseline=height;
  baseline=Math.max(baseline,height);
  const inset=scale===1?Math.max(0,win.innerHeight-height-(viewport?.offsetTop||0)):0;
  // Keep the remaining navigation space continuous throughout the animation.
  // A boolean keyboard threshold must never move the composer by a whole nav height.
  const keyboardHeight=scale===1&&(focused||opened||tracking)?Math.max(0,baseline-height,inset):0;
  const next=keyboardHeight>(opened?2:120);
  if(!focused&&keyboardHeight<=2)tracking=false;
  root.style.setProperty('--chat-viewport-height',`${scale===1?height:win.innerHeight}px`);
  root.style.setProperty('--chat-viewport-top',`${scale===1?(viewport?.offsetTop||0):0}px`);
  root.classList.add('chatScreen');
  root.style.setProperty('--chat-keyboard-inset',`${next?inset:0}px`);
  root.style.setProperty('--chat-keyboard-height',`${keyboardHeight}px`);
  root.classList.toggle('chatKeyboard',next);
  if((keyboardHeight>0||opened)&&(height!==lastHeight||keyboardHeight!==lastKeyboardHeight||next!==opened))reveal();
  lastHeight=height;lastKeyboardHeight=keyboardHeight;
  opened=next;
 };
 const schedule=()=>{if(!frame)frame=win.requestAnimationFrame(update)};
 const reset=()=>{baseline=Math.max(win.innerHeight,viewport?.height||0);width=viewport?.width||win.innerWidth;schedule()};
 viewport?.addEventListener('resize',schedule);viewport?.addEventListener('scroll',schedule);
 win.addEventListener('resize',schedule);win.addEventListener('pageshow',schedule);win.addEventListener('orientationchange',reset);
 input.addEventListener('focus',schedule);input.addEventListener('blur',schedule);
 update();
 return()=>{
  if(frame)win.cancelAnimationFrame(frame);
  viewport?.removeEventListener('resize',schedule);viewport?.removeEventListener('scroll',schedule);
  win.removeEventListener('resize',schedule);win.removeEventListener('pageshow',schedule);win.removeEventListener('orientationchange',reset);
  input.removeEventListener('focus',schedule);input.removeEventListener('blur',schedule);
  root.style.removeProperty('--chat-keyboard-inset');root.classList.remove('chatKeyboard');
  root.style.removeProperty('--chat-keyboard-height');
  root.style.removeProperty('--chat-viewport-height');root.style.removeProperty('--chat-viewport-top');root.classList.remove('chatScreen');
 };
}
