package br.com.nutrivida.avaliacao;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.AlarmClock;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.view.View;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;

/** Offline evaluation build. Only packaged, trusted assets can access the bridge. */
public class MainActivity extends Activity {
 private WebView web;
 private byte[] pendingFile;
 private ValueCallback<Uri[]> pendingChooser;
 private static final String ORIGIN="https://app.nutrivida.local/";
 @Override public void onCreate(Bundle saved){
  super.onCreate(saved);
  getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | 0x10);
  web=new WebView(this);setContentView(web);
  web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(true);
  web.getSettings().setMixedContentMode(0);web.getSettings().setSupportZoom(true);
  web.getSettings().setBuiltInZoomControls(true);web.getSettings().setDisplayZoomControls(false);
  web.addJavascriptInterface(new Bridge(),"NutriVidaAndroid");
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,WebChromeClient.FileChooserParams params){
    if(!view.getUrl().startsWith(ORIGIN))return false;
    if(pendingChooser!=null)pendingChooser.onReceiveValue(null);
    pendingChooser=callback;
    try{Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(intent,42);}catch(Exception e){pendingChooser.onReceiveValue(null);pendingChooser=null;message("Não foi possível abrir o seletor de arquivos.");}
    return true;
   }
  });
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,String url){
    if(url.startsWith(ORIGIN))return false;
    if(url.startsWith("https://")||url.startsWith("http://"))try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){message("Nenhum navegador disponível para abrir o link.");}
    return true;
   }
   @Override public WebResourceResponse shouldInterceptRequest(WebView view,String url){
    if(!url.startsWith(ORIGIN))return empty();
    try{
     String path=Uri.parse(url).getPath();if(path==null||path.equals("/"))path="/index.html";
     if(path.contains("..")||path.contains("\\"))return empty();path=path.substring(1);
     String mime=path.endsWith(".html")?"text/html":path.endsWith(".js")?"application/javascript":path.endsWith(".css")?"text/css":path.endsWith(".svg")?"image/svg+xml":path.endsWith(".png")?"image/png":path.endsWith(".webp")?"image/webp":path.endsWith(".otf")?"font/otf":"application/octet-stream";
     InputStream stream=getAssets().open(path);
     HashMap<String,String> headers=new HashMap<String,String>();
     headers.put("Cache-Control","no-cache");headers.put("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'none'; object-src 'none'; frame-src 'none'");
     return new WebResourceResponse(mime,"UTF-8",200,"OK",headers,stream);
    }catch(Exception e){return empty();}
   }
  });
  web.loadUrl(ORIGIN);
 }
 private WebResourceResponse empty(){return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",new HashMap<String,String>(),new ByteArrayInputStream(new byte[0]));}
 private void message(final String text){runOnUiThread(new Runnable(){public void run(){Toast.makeText(MainActivity.this,text,Toast.LENGTH_LONG).show();}});}
 public class Bridge {
  @JavascriptInterface public void setTheme(final boolean dark){
   runOnUiThread(new Runnable(){public void run(){
    int color=dark?0xff0e0919:0xffffffff;
    getWindow().setStatusBarColor(color);getWindow().setNavigationBarColor(color);
    getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | 0x10);
    web.setBackgroundColor(color);
   }});
  }
  @JavascriptInterface public void saveFile(final String name,final String mime,final String base64){
   if(base64==null||base64.length()>16000000){message("Arquivo grande demais para exportar.");return;}
   runOnUiThread(new Runnable(){public void run(){
    try{pendingFile=Base64.decode(base64,Base64.DEFAULT);Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(mime.equals("text/calendar")?"text/calendar":"application/json");intent.putExtra(Intent.EXTRA_TITLE,name.replaceAll("[^a-zA-Z0-9._-]","_"));startActivityForResult(intent,41);}catch(Exception e){pendingFile=null;message("Não foi possível abrir o seletor de arquivos.");}
   }});
  }
  @JavascriptInterface public void openAlarm(final int hours,final int minutes){
   if(hours<0||hours>23||minutes<0||minutes>59)return;
   runOnUiThread(new Runnable(){public void run(){try{Intent intent=new Intent(AlarmClock.ACTION_SET_ALARM);intent.putExtra(AlarmClock.EXTRA_HOUR,hours);intent.putExtra(AlarmClock.EXTRA_MINUTES,minutes);intent.putExtra(AlarmClock.EXTRA_MESSAGE,"NutriVida · Acordar");intent.putExtra(AlarmClock.EXTRA_SKIP_UI,false);startActivity(intent);}catch(Exception e){message("Abra o Relógio do celular e configure o horário de acordar.");}}});
  }
 }
 @Override protected void onActivityResult(int request,int result,Intent data){
  super.onActivityResult(request,result,data);
  if(request==42){if(pendingChooser!=null){Uri selected=result==RESULT_OK&&data!=null?data.getData():null;pendingChooser.onReceiveValue(selected!=null&&"content".equals(selected.getScheme())?new Uri[]{selected}:null);pendingChooser=null;}return;}
  if(request==41){try{if(result==RESULT_OK&&data!=null&&data.getData()!=null&&pendingFile!=null){OutputStream out=getContentResolver().openOutputStream(data.getData());if(out==null)throw new Exception();try{out.write(pendingFile);}finally{out.close();}message("Arquivo salvo.");}}catch(Exception e){message("Não foi possível salvar o arquivo.");}finally{pendingFile=null;}}
 }
 @Override public void onBackPressed(){web.evaluateJavascript("(function(){var d=document.querySelector('[aria-modal=\"true\"]');if(d){var b=d.querySelector('[data-close-dialog],button[aria-label^=\"Fechar\"],button[aria-label^=\"Close\"],button[aria-label^=\"Cerrar\"]');if(b){b.click();return true;}}if(window.nutrividaCanGoBack){window.dispatchEvent(new Event('nutrivida-back'));return true;}return false;})()",new ValueCallback<String>(){public void onReceiveValue(String value){if(!"true".equals(value))moveTaskToBack(true);}});}
 @Override protected void onPause(){super.onPause();web.onPause();}
 @Override protected void onResume(){super.onResume();if(web!=null){web.onResume();web.evaluateJavascript("window.dispatchEvent(new Event('focus'))",null);}}
 @Override protected void onDestroy(){if(pendingChooser!=null){pendingChooser.onReceiveValue(null);pendingChooser=null;}if(web!=null){web.removeJavascriptInterface("NutriVidaAndroid");web.destroy();}super.onDestroy();}
}
