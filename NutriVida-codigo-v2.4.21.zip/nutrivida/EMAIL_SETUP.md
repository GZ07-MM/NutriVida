# Acesso por e-mail — versão 2.4.21

Site e APK exigem e-mail e senha para entrar. O cadastro inicia o acesso diretamente, sem confirmação por link ou código e sem serviço de envio de mensagens. O endereço é um identificador informado pelo usuário; sua propriedade não é verificada.

No site, a conta permanece vinculada à identidade autenticada do ChatGPT. No APK, as contas e o progresso são locais e isolados por conta. As senhas são derivadas com PBKDF2, sal aleatório e SHA-256; não são armazenadas como texto nem incluídas nos backups.

Recuperação de senha por e-mail não está disponível no APK. Preserve sua senha e exporte o progresso em Perfil → Privacidade e segurança antes de desinstalar ou trocar de aparelho. Não configure serviços de envio ou chaves de e-mail para esta versão.
