# NutriVida — versão 2.4.22

Site e APK são entregues juntos nesta versão, usando as mesmas telas, estilos e regras de hábitos. O APK foi reconstruído com o código atual; não reutiliza o frontend antigo. O design aprovado e o ícone adaptativo foram preservados.

## Entregas e dados

- **Site:** React 19, Vinext/Vite, Worker Cloudflare e D1. E-mail e senha obrigatórios, sem confirmação por mensagem. O acesso hospedado continua vinculado à identidade do ChatGPT.
- **APK:** Java e WebView com os arquivos atuais incluídos no pacote. Contas com e-mail e senha locais, sem verificação de e-mail. Cada conta mantém seu próprio perfil e progresso no aparelho.
- **Atualização:** pacote `br.com.nutrivida.avaliacao`, versão 2.4.22, código 32 e assinatura original. Instale por cima do aplicativo existente. Na primeira criação de conta, o perfil local da edição anterior é vinculado a ela, preservando registros. Contas seguintes começam vazias.
- **Sincronização:** o APK funciona offline e não sincroniza automaticamente com o site. Perfil → Privacidade e segurança permite exportar e restaurar backups entre edições. A senha e a sessão não fazem parte do backup. Exporte antes de desinstalar; no APK não há recuperação de senha por e-mail.

## Funções atuais em ambas as edições

Cadastro com data digitada DD/MM/AAAA, treino escrito pelo usuário, água, refeições, sono, metas, missões, relatórios com correção de registros, loja e personalização. Sair da conta é a última opção do Perfil e mantém o progresso salvo. Temas claro e escuro são preservados ao reabrir.

A Nutri IA mantém as correções de rolagem, teclado e campo de mensagem sem contorno ao toque. Navegação: Nutri IA azul, Sono roxo, Início laranja, Relatórios verde-água e Perfil preto no claro, com adaptação no escuro. O ícone superior da Nutri IA também é azul. Nenhum desses estilos foi redesenhado nesta atualização.

O ditado usa o reconhecimento disponível no navegador e, no APK, o serviço de voz do Android. O Android solicita permissão de microfone na primeira utilização. A disponibilidade, idiomas e eventual conexão dependem do serviço de voz instalado. O texto entra no rascunho; o envio continua sendo uma ação do usuário.

## Desenvolvimento

Node 22.13 ou superior e pnpm 11.25.0. A instalação segue o lockfile.

```sh
pnpm install --frozen-lockfile
pnpm dev
pnpm build
node node_modules/typescript/bin/tsc --noEmit
pnpm test:domain
pnpm test:offline
pnpm test:accounts
pnpm test:dictation
pnpm test:api
```

O teste da API depende do build web e aplica migrações apenas no banco local. Nunca execute testes contra produção.

| Pasta | Conteúdo |
|---|---|
| `app/` | Telas compartilhadas e rotas web |
| `lib/` | Regras de hábitos, persistência, contas locais e ditado |
| `db/` e `drizzle/` | Banco web e migrações |
| `android/` | Manifest, Activity, ícone e compilação do APK |
| `public/` | Imagens, fonte e licença |
| `tests/` | Regras, API, chat, migração e isolamento das contas |

## Compilação do APK

Android 8 ou superior, com Android System WebView atualizado. Build com Java 8, JRE 17, ECJ 3.32.0, libandroid-23-java, dalvik-exchange, aapt, zipalign e apksigner 31.0.2 extraídos dos pacotes Ubuntu/Debian. `minSdkVersion=26`, `targetSdkVersion=28`; distribuição direta, sem publicação na Play Store.

```sh
NUTRIVIDA_ANDROID_TOOLS=/caminho/android-tools NUTRIVIDA_KEYSTORE=/caminho/avaliacao.jks bash android/build-apk.sh
```

O script sempre recompila o frontend atual e o código nativo, exige a mesma versão em `package.json` e no Manifest, alinha, assina e verifica `android/build/NutriVida-avaliacao.apk`. A opção de reaproveitar um APK antigo foi desativada para evitar versões diferentes entre site e aplicativo.

A chave original de avaliação, com senha `android`, deve ser mantida em segurança e não integra o código exportado. Outra assinatura impede atualizar a instalação existente. Toda futura entrega deve incluir o site publicado, o APK completo da mesma versão e os documentos correspondentes.

## Limites e avaliação

As respostas disponíveis são guiadas; IA generativa e pagamentos não estão conectados. Premium está em preparação e não faz cobranças. Alarmes internos dependem do app aberto; no Android, o botão do despertador abre o Relógio para confirmação. O reconhecimento por foto e notificações nativas em segundo plano não estão disponíveis.

Compilação, regras, persistência, migração de contas, ditado e assinatura são verificadas automaticamente. A instalação e o comportamento de teclado/microfone em aparelho físico precisam ser conferidos no celular. Consulte [AVALIACAO.md](AVALIACAO.md) para o roteiro.

## Correção de retomada do chat — 2.4.22

Ao sair, bloquear ou voltar ao aplicativo, a Nutri IA limpa as medidas transitórias do teclado e recalcula a área visível, o campo de mensagem e o espaço da navegação. Eventos de segundo plano e medidas zero não deslocam a conversa. No Android, a Activity sinaliza pausa, retomada e retorno do foco da janela. O rascunho, as mensagens, as contas e o design são preservados.

Testes de regressão simulam retorno com teclado aberto, deslocamento anterior, rotação em segundo plano, medidas indisponíveis e permissão do microfone. A confirmação em celular físico continua pendente.
